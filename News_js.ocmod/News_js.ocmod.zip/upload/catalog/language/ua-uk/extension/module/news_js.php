<?php
// Heading
$_['heading_title'] = 'Майстри';

// Text
$_['text_more'] = 'Читати далі ...';
$_['text_date_added'] = 'Додано:';
$_['text_viewed'] = '(% s ​​переглядів)';

// Buttons
$_['button_list'] = 'Подивитися всі';