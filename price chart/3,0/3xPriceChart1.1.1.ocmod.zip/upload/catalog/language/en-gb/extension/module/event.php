<?php

$_['heading_title'] = 'Events';
$_['spisok_event'] = 'Event list';


// Text
$_['button_read_more'] = 'Read more ...';
$_['text_empty'] = 'No events';
$_['text_error'] = 'No events';

//
$_['sun'] = 'Sunday';
$_['mon'] = 'Monday';
$_['tue'] = 'Tuesday';
$_['wed'] = 'Wednesday';
$_['thu'] = 'Thursday';
$_['fri'] = 'Friday';
$_['sat'] = 'Saturday';
$_['sun1'] = 'Sun';
$_['mon1'] = 'Mon';
$_['tue1'] = 'Tue';
$_['wed1'] = 'Wedn';
$_['thu1'] = 'Thu';
$_['fri1'] = 'Fri';
$_['sat1'] = 'Stu';

$_['January'] = 'January';
$_['February'] = 'February';
$_['March'] = 'March';
$_['April'] = 'April';
$_['May'] = 'May';
$_['June'] = 'June';
$_['July'] = 'July';
$_['August'] = 'August';
$_['September'] = 'September';
$_['October'] = 'October';
$_['November'] = 'November';
$_['December'] = 'December';
$_['Jan'] = 'Jan';
$_['Feb'] = 'Feby';
$_['Mar'] = 'March';
$_['Apr'] = 'Apr';
$_['May1'] = 'May';
$_['Jun'] = 'June';
$_['Jul'] = 'July';
$_['Aug'] = 'Aug';
$_['Sept'] = 'Sept';
$_['Oct'] = 'Oct';
$_['Nov'] = 'Nov';
$_['Dec'] = 'Dec';

//
$_['tooday']='Tooday';
$_['month']='Month';
$_['week']='Week';
$_['day']='Day';