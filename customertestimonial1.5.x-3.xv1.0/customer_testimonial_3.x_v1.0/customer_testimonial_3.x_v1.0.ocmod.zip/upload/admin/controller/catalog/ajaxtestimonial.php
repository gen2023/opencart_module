<?php
	class ControllerCatalogAjaxTestimonial extends Controller { 
		private $error = array();
		
		public function index() {
			$this->load->language('catalog/ajaxtestimonial');
			
			$this->document->setTitle($this->language->get('heading_title'));
			
			$this->load->model('catalog/ajaxtestimonial');
			
			$this->getList();
			
			$this->model_catalog_ajaxtestimonial->createDatabaseTables();
		}
		
		public function insert() {
			$this->load->language('catalog/ajaxtestimonial');
			
			$this->document->SetTitle($this->language->get('heading_title'));
			
			$this->load->model('catalog/ajaxtestimonial');
			
			if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
				$this->model_catalog_ajaxtestimonial->addajaxtestimonial($this->request->post);
				
				$this->session->data['success'] = $this->language->get('text_success');
				
				$url = '';
				
				if (isset($this->request->get['page'])) {
					$url .= '&page=' . $this->request->get['page'];
				}
				
				if (isset($this->request->get['sort'])) {
					$url .= '&sort=' . $this->request->get['sort'];
				}
				
				if (isset($this->request->get['order'])) {
					$url .= '&order=' . $this->request->get['order'];
				}
				
				$this->response->redirect($this->url->link('catalog/ajaxtestimonial', 'user_token=' . $this->session->data['user_token']. $url, true));
			}
			
			$this->getForm(true);
		}
		
		public function update() {
			$this->load->language('catalog/ajaxtestimonial');
			
			$this->document->SetTitle( $this->language->get('heading_title') );
			
			$this->load->model('catalog/ajaxtestimonial');
			
			if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
				$this->model_catalog_ajaxtestimonial->editajaxtestimonial($this->request->get['ajaxtestimonial_id'], $this->request->post);
				
				$this->session->data['success'] = $this->language->get('text_success');
				
				$url = '';
				
				if (isset($this->request->get['page'])) {
					$url .= '&page=' . $this->request->get['page'];
				}
				
				if (isset($this->request->get['sort'])) {
					$url .= '&sort=' . $this->request->get['sort'];
				}
				
				if (isset($this->request->get['order'])) {
					$url .= '&order=' . $this->request->get['order'];
				}
				
				$this->response->redirect($this->url->link('catalog/ajaxtestimonial', 'user_token=' . $this->session->data['user_token']. $url, true));
				
			}
			
			$this->getForm(false);
		}
		
		public function delete() {
			$this->load->language('catalog/ajaxtestimonial');
			
			$this->document->SetTitle( $this->language->get('heading_title'));
			
			$this->load->model('catalog/ajaxtestimonial');
			
			if (isset($this->request->post['selected']) && $this->validateDelete()) {
				foreach ($this->request->post['selected'] as $ajaxtestimonial_id) {
					$this->model_catalog_ajaxtestimonial->deleteajaxtestimonial($ajaxtestimonial_id);
				}
				
				$this->session->data['success'] = $this->language->get('text_success');
				
				$url = '';
				
				if (isset($this->request->get['page'])) {
					$url .= '&page=' . $this->request->get['page'];
				}
				
				if (isset($this->request->get['sort'])) {
					$url .= '&sort=' . $this->request->get['sort'];
				}
				
				if (isset($this->request->get['order'])) {
					$url .= '&order=' . $this->request->get['order'];
				}
				
				$this->response->redirect($this->url->link('catalog/ajaxtestimonial', 'user_token=' . $this->session->data['user_token']. $url, true));
				
			}
			
			$this->getList();
		}
		
		private function getList() {
			if (isset($this->request->get['page'])) {
				$page = $this->request->get['page'];
				} else {
				$page = 1;
			}
			
			if (isset($this->request->get['sort'])) {
				$sort = $this->request->get['sort'];
				} else {
				$sort = 't.date_added';
			}
			
			if (isset($this->request->get['order'])) {
				$order = $this->request->get['order'];
				} else {
				$order = 'DESC';
			}
			
			$url = '';
			
			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}
			
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}
			
			$data['breadcrumbs'] = array();
			
			$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'user_token=' . $this->session->data['user_token'], true)
			);
			
			$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('catalog/ajaxtestimonial', 'user_token=' . $this->session->data['user_token'] . $url, true)
			);
			
			$data['add'] = $this->url->link('catalog/ajaxtestimonial/insert', 'user_token=' . $this->session->data['user_token'] . $url, true);
			$data['delete'] = $this->url->link('catalog/ajaxtestimonial/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);	
			$data['module_settings_path'] = $this->url->link('module/ajaxtestimonial', 'user_token=' . $this->session->data['user_token'] . $url, true);	
			$data['text_module_settings'] = $this->language->get('text_module_settings');
			
			$data['ajaxtestimonials'] = array();
			
			$dataFilter = array(
			'sort'  => $sort,
			'order' => $order,
			'start' => ($page - 1) * 10,
			'limit' => 10
			);
			
			$ajaxtestimonial_total = $this->model_catalog_ajaxtestimonial->getTotalajaxtestimonials();
			$data['ajaxtestimonial_total'] = $ajaxtestimonial_total;
			
			if ($ajaxtestimonial_total != -1) {
				$results = $this->model_catalog_ajaxtestimonial->getajaxtestimonials($dataFilter);
				}else{
				$results = array();
				$ajaxtestimonial_total = 0;
			}
			
    		foreach ($results as $result) {
				$action = array();
				
				$action[] = array(
				'text' => $this->language->get('text_edit'),
				'href' => $this->url->link('catalog/ajaxtestimonial/update', 'user_token=' . $this->session->data['user_token']. '&ajaxtestimonial_id=' . $result['ajaxtestimonial_id'] , true)
				);
				
				$result['description'] = strip_tags($result['description']);
				
				$my_replys = array();
				$reply = array();
				$my_replys = $this->model_catalog_ajaxtestimonial->getajaxtestimonialsReply($result['ajaxtestimonial_id']);
				
				if ($my_replys){
					foreach ($my_replys as $my_reply) {			
						$actions = array();
						
						$actions[] = array(
						'text' => $this->language->get('text_edit'),
						'href' => $this->url->link('catalog/ajaxtestimonial/update', 'user_token=' . $this->session->data['user_token']. '&ajaxtestimonial_id=' . $my_reply['ajaxtestimonial_id'] , 'SSL')
						);
						
						$reply[] = array(
						'id'		=> $my_reply['ajaxtestimonial_id'],
						'status'		=> ($my_reply['status'] ? $this->language->get('text_enabled') : $this->language->get('text_disabled')),
						'action'     	=> $actions,
						'name'		=> $my_reply['name'],
						'description'	=> $my_reply['description'],
						'date_added'	=> date($this->config->get('ajaxtestimonial_all_page_date_format'), strtotime($result['date_added']))
						);
					}
				}
				
				$data['ajaxtestimonials'][] = array(
				'reply' => $reply,
				'ajaxtestimonial_id' => $result['ajaxtestimonial_id'],
				'parent_testimonial_id' => $result['parent_testimonial_id'],
				'name'		=> $result['name'],
				'description'	=> $result['description'],
				'phone'		=> $result['phone'],
				'date_added' 	=> $result['date_added'],
				'status' 		=> ($result['status'] ? $this->language->get('text_enabled') : $this->language->get('text_disabled')),
				'selected'   	=> isset($this->request->post['selected']) && in_array($result['ajaxtestimonial_id'], $this->request->post['selected']),
				'action'     	=> $action
				);
			}	
			
			$data['heading_title'] = $this->language->get('heading_title');
			
			$data['text_no_results'] = $this->language->get('text_no_results');
			$data['text_list'] = $this->language->get('text_list');
			
			$data['column_description'] = $this->language->get('column_description');
			
			$data['column_date_added'] = $this->language->get('column_date_added');
			$data['column_status'] = $this->language->get('column_status');
			$data['column_action'] = $this->language->get('column_action');		
			$data['column_name'] = $this->language->get('column_name');		
			$data['column_phone'] = $this->language->get('column_phone');
			$data['button_add'] = $this->language->get('button_add');
			$data['button_delete'] = $this->language->get('button_delete');
			$data['text_confirm'] = $this->language->get('button_confirm');
			$data['entry_install_first'] = $this->language->get('entry_install_first');;
			
			if (isset($this->error['warning'])) {
				$data['error_warning'] = $this->error['warning'];
				} else {
				$data['error_warning'] = '';
			}
			
			if (isset($this->session->data['success'])) {
				$data['success'] = $this->session->data['success'];
				
				unset($this->session->data['success']);
				} else {
				$data['success'] = '';
			}
			
			$url = '';
			
			if ($order == 'ASC') {
				$url .= '&order=' .  'DESC';
				} else {
				$url .= '&order=' .  'ASC';
			}
			
			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			
			$data['sort_date_added'] = $this->url->link('catalog/ajaxtestimonial', 'user_token=' . $this->session->data['user_token'] . '&sort=t.date_added' . $url, true);		
			$data['sort_status'] = $this->url->link('catalog/ajaxtestimonial', 'user_token=' . $this->session->data['user_token'] . '&sort=t.status' . $url, true);		
			$data['sort_name'] = $this->url->link('catalog/ajaxtestimonial', 'user_token=' . $this->session->data['user_token'] . '&sort=t.name' . $url, true);		
			$data['sort_description'] = $this->url->link('catalog/ajaxtestimonial', 'user_token=' . $this->session->data['user_token'] . '&sort=td.description' . $url, true);		
			
			$url = '';
			
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}
			
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}
			
			$pagination = new Pagination();
			$pagination->total = $ajaxtestimonial_total;
			$pagination->page = $page;
			$pagination->limit = $this->config->get('config_limit_admin'); 
			$pagination->text = $this->language->get('text_pagination');
			
			$pagination->url = $this->url->link('catalog/ajaxtestimonial', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);		
			
			$data['results'] = sprintf($this->language->get('text_pagination'), ($ajaxtestimonial_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($ajaxtestimonial_total - $this->config->get('config_limit_admin'))) ? $ajaxtestimonial_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $ajaxtestimonial_total, ceil($ajaxtestimonial_total / $this->config->get('config_limit_admin')));
			
			$data['pagination'] = $pagination->render();
			
			$data['sort'] = $sort;
			$data['order'] = $order;
			
			$data['header'] = $this->load->controller('common/header');
			$data['column_left'] = $this->load->controller('common/column_left');
			$data['footer'] = $this->load->controller('common/footer');
			
			$this->response->setOutput($this->load->view('catalog/ajaxtestimonial_list', $data));
		}
		
		private function getForm($is_edit) {
			
			$data['is_edit'] = $is_edit;
			$data['heading_title'] = $this->language->get('heading_title');
			$data['text_form'] = $this->language->get('text_form');
			
			$data['entry_status'] = $this->language->get('entry_status');
			$data['entry_description'] = $this->language->get('entry_description');
			$data['entry_date_added'] = $this->language->get('entry_date_added');
			$data['entry_name'] = $this->language->get('entry_name');
			$data['entry_phone'] = $this->language->get('entry_phone');
			$data['text_enabled'] = $this->language->get('text_enabled');
			$data['text_disabled'] = $this->language->get('text_disabled');
			$data['entry_email'] = $this->language->get('entry_email');
			$data['entry_page'] = $this->language->get('entry_page');
			
			$data['entry_rating'] = $this->language->get('entry_rating');
			$data['entry_bad'] = $this->language->get('entry_bad');
			$data['entry_good'] = $this->language->get('entry_good');
			
			$data['button_save'] = $this->language->get('button_save');
			$data['button_cancel'] = $this->language->get('button_cancel');
			
			if (isset($this->error['warning'])) {
				$data['error_warning'] = $this->error['warning'];
				} else {
				$data['error_warning'] = '';
			}
			
			if (isset($this->error['name'])) {
				$data['error_name'] = $this->error['name'];
				} else {
				$data['error_name'] = '';
			}
			
			if (isset($this->error['description'])) {
				$data['error_description'] = $this->error['description'];
				} else {
				$data['error_description'] = '';
			}
			
			$url = '';
			
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}
			
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}
			
			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			
			$data['breadcrumbs'] = array();
			
			$data['breadcrumbs'][] = array(
			'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'user_token=' . $this->session->data['user_token'], true)
			);
			
			$data['breadcrumbs'][] = array(
			'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('catalog/ajaxtestimonial', 'user_token=' . $this->session->data['user_token'] . $url, true)
			);
			
			$url = '';
			
			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			
			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}
			
			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}
			
			if (!isset($this->request->get['ajaxtestimonial_id'])) {
				$data['action'] = $this->url->link('catalog/ajaxtestimonial/insert', 'user_token=' . $this->session->data['user_token'] . $url, true);		
				} else {
				$data['action'] = $this->url->link('catalog/ajaxtestimonial/update', 'user_token=' . $this->session->data['user_token'] . '&ajaxtestimonial_id=' . $this->request->get['ajaxtestimonial_id'] . $url, true);
			}
			
			$data['cancel'] = $this->url->link('catalog/ajaxtestimonial', 'user_token=' . $this->session->data['user_token'] . $url, true);
			
			$data['user_token'] = $this->session->data['user_token'];
			
			if (isset($this->request->get['ajaxtestimonial_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
				$ajaxtestimonial_info = $this->model_catalog_ajaxtestimonial->getajaxtestimonial($this->request->get['ajaxtestimonial_id']);
			}
			
			if (isset($ajaxtestimonial_info['reply'])) {
				$data['reply'] = $ajaxtestimonial_info['reply'];
				}else{
				$data['reply'] = '';
			}
			
			if ($data['reply'] == 1) {
				$data['hidden'] = 'style="display:none"';
				}else{
				$data['hidden'] = '';
			}
			
			$this->load->model('localisation/language');
			
			$data['languages'] = $this->model_localisation_language->getLanguages();
			
			if (isset($this->request->post['ajaxtestimonial_description'])) {
				$data['ajaxtestimonial_description'] = $this->request->post['ajaxtestimonial_description'];
				} elseif (isset($this->request->get['ajaxtestimonial_id'])) {
				$data['ajaxtestimonial_description'] = $this->model_catalog_ajaxtestimonial->getajaxtestimonialDescriptions($ajaxtestimonial_info['ajaxtestimonial_id']);
				} else {
				$data['ajaxtestimonial_description'] = array();
			}
			
			if (isset($this->request->post['status'])) {
				$data['status'] = $this->request->post['status'];
				} elseif (isset($ajaxtestimonial_info)) {
				$data['status'] = $ajaxtestimonial_info['status'];
				} else {
				$data['status'] = 1;
			}
			
			if (isset($this->request->post['name'])) {
				$data['name'] = $this->request->post['name'];
				} elseif (isset($ajaxtestimonial_info)) {
				$data['name'] = $ajaxtestimonial_info['name'];
				} else {
				$data['name'] = '';
			}
			
			if (isset($this->request->post['phone'])) {
				$data['phone'] = $this->request->post['phone'];
				} elseif (isset($ajaxtestimonial_info)) {
				$data['phone'] = $ajaxtestimonial_info['phone'];
				} else {
				$data['phone'] = '';
			}
			
			if (isset($this->request->post['email'])) {
				$data['email'] = $this->request->post['email'];
				} elseif (isset($ajaxtestimonial_info)) {
				$data['email'] = $ajaxtestimonial_info['email'];
				} else {
				$data['email'] = '';
			}
			
			if (isset($this->request->post['date_added'])) {
				$data['date_added'] = $this->request->post['date_added'];
				} elseif (isset($ajaxtestimonial_info)) {
				$data['date_added'] = $ajaxtestimonial_info['date_added'];
				} else {
				$data['date_added'] = $this->model_catalog_ajaxtestimonial->getCurrentDateTime();
			}
			
			if (!$data['reply']) {
				if (isset($this->request->post['rating'])) {
					$data['rating'] = $this->request->post['rating'];
					} elseif (isset($ajaxtestimonial_info)) {
					$data['rating'] = $ajaxtestimonial_info['rating'];
					
					} else {
					
					if ($this->config->get('ajaxtestimonial_default_rating') == '') {
						$data['rating'] = '3';
						} else {
						$data['rating'] = $this->config->get('ajaxtestimonial_default_rating');
					}
				}	
				
				} else {
				$data['rating'] = '1';
			}
			
			$data['header'] = $this->load->controller('common/header');
			$data['column_left'] = $this->load->controller('common/column_left');
			$data['footer'] = $this->load->controller('common/footer');
			
			$this->response->setOutput($this->load->view('catalog/ajaxtestimonial_form', $data));
		}
		
		private function validateForm() {
			if (!$this->user->hasPermission('modify', 'catalog/ajaxtestimonial')) {
				$this->error['warning'] = $this->language->get('error_permission');
			}
			
			foreach ($this->request->post['ajaxtestimonial_description'] as $language_id => $value) {
				if (strlen(utf8_decode($value['description'])) != 0) {
					$this->request->post['ajaxtestimonial_description'][$language_id]['description'] = (html_entity_decode($value['description']));
				}		
			}
			
			$desc = '';
			foreach ($this->request->post['ajaxtestimonial_description'] as $language_id => $value) {
				if (strlen(utf8_decode($value['description'])) != 0) {
					$desc = $value['description'];
					break;
				}		
			}
			
			if ($desc == '') {
				foreach ($this->request->post['ajaxtestimonial_description'] as $language_id => $value) {
					$this->error['description'][$language_id] = $this->language->get('error_description');
				}
				} else {
				foreach ($this->request->post['ajaxtestimonial_description'] as $language_id => $value) {
					if (strlen(utf8_decode($value['description'])) == 0) $this->request->post['ajaxtestimonial_description'][$language_id]['description'] = $desc;
				}
			}
			
			if (!$this->error) {
				return TRUE;
				} else {
				return FALSE;
			}
		}
		
		private function validateDelete() {
			if (!$this->user->hasPermission('modify', 'catalog/ajaxtestimonial')) {
				$this->error['warning'] = $this->language->get('error_permission');
			}
			
			if (!$this->error) {
				return TRUE;
				} else {
				return FALSE;
			}
		}
	}									