<?php
// Heading 
$_['heading_title']	  	= 'Отзывы';
$_['ajaxtestimonial_form'] 	= 'Оставить отзыв';
$_['text_more']			= '...';
$_['text_more2']			= 'Подробнее';
$_['show_all']			= 'Показать все отзывы';
$_['text_subject']		= 'Покупатель %s оставил отзыв о магазине %s';
$_['text_header']			= 'Текст отзыва: ';
$_['text_footer']			= '';
?>