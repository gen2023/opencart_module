<?php
$_['heading_title'] = 'Module for offices';

$_['text_module'] = 'Modules';
$_['text_edit'] = 'Module settings';
$_['entry_status'] = 'Status';
$_['text_success'] = 'Module settings updated';