<?php
// Heading
$_['heading_title'] = 'Популярний продукт';

// Text
$_['text_tax']      = 'Без налога:';