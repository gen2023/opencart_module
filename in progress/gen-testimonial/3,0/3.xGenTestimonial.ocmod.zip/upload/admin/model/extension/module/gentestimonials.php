<?php
class ModelExtensionModuleEvents extends Model {
	
	public function install() {
		
	/*	$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "gentestimonial` (`testimonial_id` int(11) NOT NULL auto_increment, `status` int(1) NOT NULL default '0', `alternativeLink` VARCHAR(255) COLLATE utf8_general_ci default NULL, `image` VARCHAR(255) COLLATE utf8_general_ci default NULL, `color` VARCHAR(255) COLLATE utf8_general_ci default NULL, `product_id` int(11) default NULL, `date_from` date default NULL, `date_to` date default NULL,`sort_order` int(3) default NULL, `time_to` time default NULL, `time_from` time default NULL, PRIMARY KEY (`testimonial_id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci");			
		
		$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "gentestimonial_description` (`testimonial_id` int(11) NOT NULL default '0', `language_id` int(11) NOT NULL default '0', `title` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL, `mindescription` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL, `description` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,  `meta_title` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,  `meta_h1` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL, `meta_description` VARCHAR(255) COLLATE utf8_general_ci NOT NULL, `meta_keyword` varchar(255) COLLATE utf8_general_ci NOT NULL, PRIMARY KEY (`testimonial_id`,`language_id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci");	
		
		$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "gentestimonial_to_store` (`testimonial_id` int(11) NOT NULL, `store_id` int(11) NOT NULL, PRIMARY KEY (`testimonial_id`, `store_id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci");

		$query1=$this->db->query("SELECT * FROM `" . DB_PREFIX . "seo_url` WHERE `query`='extension/module/gentestimonial_list'");
		$num_rows1 = $query1->num_rows;
		if ($num_rows1==0)	{
			$this->db->query("INSERT INTO `" . DB_PREFIX . "seo_url` SET `query` = 'extension/module/gentestimonial_list', `keyword` = 'testimonial_list'");
		}
		
		$query1=$this->db->query("SELECT * FROM `" . DB_PREFIX . "seo_url` WHERE `query`='extension/module/gentestimonial_detail'");
		$num_rows1 = $query1->num_rows;
		if ($num_rows1==0)	{
			$this->db->query("INSERT INTO `" . DB_PREFIX . "seo_url` SET `query` = 'extension/module/gentestimonial_detail', `keyword` = 'testimonial_detail'");
		}

		$query2=$this->db->query("SELECT * FROM `" . DB_PREFIX . "seo_url` WHERE `query`='extension/module/gentestimonial'");
		$num_rows2 = $query2->num_rows;
		if ($num_rows2==0)	{
			$this->db->query("INSERT INTO `" . DB_PREFIX . "seo_url` SET `query` = 'extension/module/gentestimonial', `keyword` = 'testimonial'");
		}

		$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "gentestimonial_setting` (`testimonial_value_id` int(11) NOT NULL auto_increment,`value1` VARCHAR(255) COLLATE utf8_general_ci default NULL, `value2` VARCHAR(255) COLLATE utf8_general_ci default NULL, `rightColumnMenu` VARCHAR(255) COLLATE utf8_general_ci default NULL, `initialView` VARCHAR(255) COLLATE utf8_general_ci default NULL, `firstDay` int(1) COLLATE utf8_general_ci default 1, `dayMaxEvents` int(11) COLLATE utf8_general_ci default 1, `event_share` int(1) NOT NULL, PRIMARY KEY (`testimonial_value_id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci");
		
		$query3=$this->db->query("SELECT * FROM `" . DB_PREFIX . "gentestimonial_setting` WHERE value1='26028713'");
		$num_rows3 = $query3->num_rows;
		if ($num_rows3==0)	{
			$this->db->query("INSERT INTO `" . DB_PREFIX . "gentestimonial_setting` SET value1 = '26028713', value2 = '', initialView='dayGridMonth'");
		}*/
		
}

	public function addTestimonial($data) {

	/*	$this->db->query("UPDATE " . DB_PREFIX . "gentestimonial_setting SET value2 = '" . $this->db->escape($data['license']) . "' WHERE gentestimonial_value_id = '1'");
		 
		$this->db->query("INSERT INTO " . DB_PREFIX . "gentestimonial SET status = '" . (int)$data['status'] . "',alternativeLink = '" . $this->db->escape($data['alternativeLink']). "',  date_from = now(), date_to = now(), sort_order = '" . (int)$data['sort_order'] . "'");
	
		$testimonial_id = $this->db->getLastId();
	
		if (isset($data['image'])) {
			$this->db->query("UPDATE " . DB_PREFIX . "gentestimonial SET image = '" . $this->db->escape($data['image']) . "' WHERE testimonial_id = '" . (int)$testimonial_id . "'");
		}
		
		if (isset($data['event_color'])) {
			$this->db->query("UPDATE " . DB_PREFIX . "gentestimonial SET color = '" . $this->db->escape($data['event_color']) . "' WHERE testimonial_id = '" . (int)$testimonial_id . "'");
		}
		
		if (isset($data['product'])) {
			$this->db->query("UPDATE " . DB_PREFIX . "gentestimonial SET product_id = '" .  $this->db->escape($data["product"][0]) . "' WHERE testimonial_id = '" . (int)$testimonial_id . "'");
		}
		
		if (isset($data['product_id'])) {
			$this->db->query("UPDATE " . DB_PREFIX . "gentestimonial SET product_id = '" .  $this->db->escape($data["product_id"]) . "' WHERE testimonial_id = '" . (int)$testimonial_id . "'");
			
		}
	
		if (isset($data['date_from'])) {
			$this->db->query("UPDATE " . DB_PREFIX . "gentestimonial SET date_from = '" . $this->db->escape($data['date_from']) . "' WHERE testimonial_id = '" . (int)$testimonial_id . "'");
		}
		
		if (isset($data['date_to'])) {
			$this->db->query("UPDATE " . DB_PREFIX . "gentestimonial SET date_to = '" . $this->db->escape($data['date_to']) . "' WHERE testimonial_id = '" . (int)$testimonial_id . "'");
		}
		
		if (isset($data['time_from'])) {
			$this->db->query("UPDATE " . DB_PREFIX . "gentestimonial SET time_from = '" . $this->db->escape($data['time_from']) . "' WHERE testimonial_id = '" . (int)$testimonial_id . "'");
		}
		
		if (isset($data['time_to'])) {
			$this->db->query("UPDATE " . DB_PREFIX . "gentestimonial SET time_to = '" . $this->db->escape($data['time_to']) . "' WHERE testimonial_id = '" . (int)$testimonial_id . "'");
		}
	
		foreach ($data['events_description'] as $language_id => $value) {
			$this->db->query("INSERT INTO " . DB_PREFIX . "events_description SET testimonial_id = '" . (int)$testimonial_id . "', language_id = '" . (int)$language_id . "', title = '" . $this->db->escape($value['title']) . "',  mindescription = '" . $this->db->escape($value['mindescription']) . "',  description = '" . $this->db->escape($value['description']) . "', meta_title = '" . $this->db->escape($value['meta_title']) . "',  meta_h1 = '" . $this->db->escape($value['meta_h1']) . "', meta_description = '" . $this->db->escape($value['meta_description']) . "', meta_keyword = '" . $this->db->escape($value['meta_keyword']) . "'");
		}
	
		if (isset($data['events_store'])) {
			foreach ($data['events_store'] as $store_id) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "events_to_store SET testimonial_id = '" . (int)$testimonial_id . "', store_id = '" . (int)$store_id . "'");
			}
		}
		
		if ($data['keyword']) {
			$this->db->query("INSERT INTO " . DB_PREFIX . "seo_url SET query = 'testimonial_id=" . (int)$testimonial_id . "', keyword = '" . $this->db->escape($data['keyword']) . "'");
		}
	
		$this->cache->delete('gentestimonial');*/
	}

	public function editTestimonial($testimonial_id, $data) {

	/*		$this->db->query("UPDATE " . DB_PREFIX . "gentestimonial SET status = '" . (int)$data['status'] . "',alternativeLink = '" . $this->db->escape($data['alternativeLink']). "', sort_order = '" . (int)$data['sort_order'] . "' WHERE testimonial_id = '" . (int)$testimonial_id . "'");
			
		if (isset($data['product'])) {
			$this->db->query("UPDATE " . DB_PREFIX . "gentestimonial SET product_id = '" . $this->db->escape($data["product"][0]) . "' WHERE testimonial_id = '" . (int)$testimonial_id . "'");
		}
		else{
			$this->db->query("UPDATE " . DB_PREFIX . "gentestimonial SET product_id = '0' WHERE testimonial_id = '" . (int)$testimonial_id . "'");
		}
		
		if (isset($data['image'])) {
			$this->db->query("UPDATE " . DB_PREFIX . "gentestimonial SET image = '" . $this->db->escape($data['image']) . "' WHERE testimonial_id = '" . (int)$testimonial_id . "'");
		}
		
		if (isset($data['event_color'])) {
			$this->db->query("UPDATE " . DB_PREFIX . "gentestimonial SET color = '" . $this->db->escape($data['event_color']) . "' WHERE testimonial_id = '" . (int)$testimonial_id . "'");
		}
		
		if (isset($data['date_from'])) {
			$this->db->query("UPDATE " . DB_PREFIX . "gentestimonial SET date_from = '" . $this->db->escape($data['date_from']) . "' WHERE testimonial_id = '" . (int)$testimonial_id . "'");
		}
		
		if (isset($data['date_to'])) {
			$this->db->query("UPDATE " . DB_PREFIX . "gentestimonial SET date_to = '" . $this->db->escape($data['date_to']) . "' WHERE testimonial_id = '" . (int)$testimonial_id . "'");
		}
		
		if (isset($data['time_from'])) {
			$this->db->query("UPDATE " . DB_PREFIX . "gentestimonial SET time_from = '" . $this->db->escape($data['time_from']) . "' WHERE testimonial_id = '" . (int)$testimonial_id . "'");
		}
		
		if (isset($data['time_to'])) {
			$this->db->query("UPDATE " . DB_PREFIX . "gentestimonial SET time_to = '" . $this->db->escape($data['time_to']) . "' WHERE testimonial_id = '" . (int)$testimonial_id . "'");
		}
		
		$this->db->query("DELETE FROM " . DB_PREFIX . "events_description WHERE testimonial_id = '" . (int)$testimonial_id . "'");
	
		foreach ($data['events_description'] as $language_id => $value) {
			$this->db->query("INSERT INTO " . DB_PREFIX . "events_description SET testimonial_id = '" . (int)$testimonial_id . "', language_id = '" . (int)$language_id . "', title = '" . $this->db->escape($value['title']) . "', mindescription = '" . $this->db->escape($value['mindescription']) . "', description = '" . $this->db->escape($value['description']) . "', meta_title = '" . $this->db->escape($value['meta_title']) . "',  meta_h1 = '" . $this->db->escape($value['meta_h1']) . "', meta_description = '" . $this->db->escape($value['meta_description']) . "', meta_keyword = '" . $this->db->escape($value['meta_keyword']) . "'");
		}
	
		$this->db->query("DELETE FROM " . DB_PREFIX . "events_to_store WHERE testimonial_id = '" . (int)$testimonial_id . "'");
	
		if (isset($data['events_store'])) {		
			foreach ($data['events_store'] as $store_id) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "events_to_store SET testimonial_id = '" . (int)$testimonial_id . "', store_id = '" . (int)$store_id . "'");
			}
		}
	
		$this->db->query("DELETE FROM " . DB_PREFIX . "seo_url WHERE query = 'testimonial_id=" . (int)$testimonial_id . "'");
	
		if ($data['keyword']) {
			$this->db->query("INSERT INTO " . DB_PREFIX . "seo_url SET query = 'testimonial_id=" . (int)$testimonial_id . "', keyword = '" . $this->db->escape($data['keyword']) . "'");
		}
	
		$this->cache->delete('gentestimonial');*/
	}

	public function deleteTestimonial($testimonial_id) { 
	/*	$this->db->query("DELETE FROM " . DB_PREFIX . "gentestimonial WHERE testimonial_id = '" . (int)$testimonial_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "events_description WHERE testimonial_id = '" . (int)$testimonial_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "events_to_store WHERE testimonial_id = '" . (int)$testimonial_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "seo_url WHERE query = 'testimonial_id=" . (int)$testimonial_id . "'");
	
		$this->cache->delete('gentestimonial');*/
	}

	public function getEventsList($data = array()) {
	/*	if ($data) {
			$sql = "SELECT * FROM " . DB_PREFIX . "gentestimonial n LEFT JOIN " . DB_PREFIX . "events_description nd ON (n.testimonial_id = nd.testimonial_id) WHERE nd.language_id = '" . (int)$this->config->get('config_language_id') . "'";

			$sort_data = array(
				'nd.title',
				'n.date_to'
			);

			if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
				$sql .= " ORDER BY " . $data['sort'];
			} else {
				$sql .= " ORDER BY nd.title";
			}

			if (isset($data['order']) && ($data['order'] == 'DESC')) {
				$sql .= " DESC";
			} else {
				$sql .= " ASC";
			}

			if (isset($data['start']) || isset($data['limit'])) {
				if ($data['start'] < 0) {
					$data['start'] = 0;
				}

				if ($data['limit'] < 1) {
					$data['limit'] = 20;
				}

				$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
			}

			$query = $this->db->query($sql);

			return $query->rows;
		} else {
			$events_data = $this->cache->get('gentestimonial.' . (int)$this->config->get('config_language_id'));

			if (!$events_data) {
				$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "gentestimonial n LEFT JOIN " . DB_PREFIX . "events_description nd ON (n.testimonial_id = nd.testimonial_id) WHERE nd.language_id = '" . (int)$this->config->get('config_language_id') . "' ORDER BY nd.title");

				$events_data = $query->rows;

				$this->cache->set('gentestimonial.' . (int)$this->config->get('config_language_id'), $events_data);
			}

			return $events_data;
		}*/
	}

	public function getTestimonialsStory($testimonial_id) { 
	/*	$query = $this->db->query("SELECT DISTINCT *, (SELECT keyword FROM " . DB_PREFIX . "seo_url WHERE query = 'testimonial_id=" . (int)$testimonial_id . "') AS keyword FROM " . DB_PREFIX . "gentestimonial n LEFT JOIN " . DB_PREFIX . "events_description nd ON (n.testimonial_id = nd.testimonial_id) WHERE n.testimonial_id = '" . (int)$testimonial_id . "' AND nd.language_id = '" . (int)$this->config->get('config_language_id') . "'");
	
		return $query->row;*/
	}

	public function getTestimonialDescriptions($testimonial_id) { 
	/*	$events_description_data = array();
	
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "events_description WHERE testimonial_id = '" . (int)$testimonial_id . "'");
	
		foreach ($query->rows as $result) {
			$events_description_data[$result['language_id']] = array(
				'title'            	=> $result['title'],
				'mindescription'    => $result['mindescription'],
				'description'      	=> $result['description'],
				'meta_title'        => $result['meta_title'],
				'meta_h1'           => $result['meta_h1'],
				'meta_description' 	=> $result['meta_description'],
				'meta_keyword'		=> $result['meta_keyword'],
			);
		}
	
		return $events_description_data;*/
	}

	public function getTestimonialsStores($testimonial_id) { 
	/*	$eventspage_store_data = array();
	
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "events_to_store WHERE testimonial_id = '" . (int)$testimonial_id . "'");
		
		foreach ($query->rows as $result) {
			$eventspage_store_data[] = $result['store_id'];
		}
	
		return $eventspage_store_data;*/
	}

	public function getTotalTestimonial() { 

     /*	$query = $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "events");
	
		return $query->row['total'];*/
	}

	public function setTestimonialsSetting($data) {

	/*	if ($data) {
			$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "seo_url WHERE query = 'extension/module/event_list'");
			
			if ($query) {
				$this->db->query("DELETE FROM `" . DB_PREFIX . "seo_url` WHERE query = 'extension/module/event_list'");
				$this->db->query("INSERT INTO `" . DB_PREFIX . "seo_url` SET `query` = 'extension/module/event_list', `keyword` = '" . $this->db->escape($data['eventslist_url']) . "'");
			}else{
				$this->db->query("INSERT INTO `" . DB_PREFIX . "seo_url` SET `query` = 'extension/module/event_list', `keyword` = '" . $this->db->escape($data['eventslist_url']) . "'");
			}
		
			$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "seo_url WHERE query = 'extension/module/gentestimonials'");
			if ($query) {
				$this->db->query("DELETE FROM `" . DB_PREFIX . "seo_url` WHERE query = 'extension/module/gentestimonials'");
				$this->db->query("INSERT INTO `" . DB_PREFIX . "seo_url` SET `query` = 'extension/module/event', `keyword` = '" . $this->db->escape($data['events_url']) . "'");
			}else{
				$this->db->query("INSERT INTO `" . DB_PREFIX . "seo_url` SET `query` = 'extension/module/gentestimonials', `keyword` = '" . $this->db->escape($data['events_url']) . "'");
			}
			
			$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "seo_url WHERE query = 'extension/module/event_detail'");
			
			if ($query) {
				$this->db->query("DELETE FROM " . DB_PREFIX . "seo_url WHERE query = 'extension/module/event_detail'");
				$this->db->query("INSERT INTO `" . DB_PREFIX . "seo_url` SET `query` = 'extension/module/event_detail', `keyword` = '" . $this->db->escape($data['eventsDetail_url']) . "'");
			}else{
				$this->db->query("INSERT INTO `" . DB_PREFIX . "seo_url` SET `query` = 'extension/module/event_detail', `keyword` = '" . $this->db->escape($data['eventsDetail_url']) . "'");
			}
			
		} 
		if (isset($data['rightMenu'])){			
				$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "setting` WHERE `code` = 'setting_module_genEvents' AND `key`='rightMenu'");
			
				if ($query) {
					$this->db->query("DELETE FROM `" . DB_PREFIX . "setting` WHERE `code` = 'setting_module_genEvents' AND `key`='rightMenu'");
				}
				$this->db->query("INSERT INTO `" . DB_PREFIX . "setting` SET `code` = 'setting_module_genEvents', `key`='rightMenu', `value` = '" . $this->db->escape(json_encode($data['rightMenu'])) . "', `serialized`='0'");

			} 
			
		 
		if (isset($data['rightColumnMenu'])){
		$rightColumnMenu = implode(",", $data['rightColumnMenu']);
		}
		else
		{
			$rightColumnMenu = '';
		}
		if (isset($data['event_initialView'])){$event_initialView=$data['event_initialView'];}else {$event_initialView='dayGridMonth';}

		
		$this->db->query("UPDATE " . DB_PREFIX . "events_setting SET firstDay = '" . (int)$data['event_firstDay'] . "', dayMaxEvents = '" . (int)$data['dayMaxEvents'] . "', rightColumnMenu = '" . $this->db->escape($rightColumnMenu) . "', initialView = '" . $this->db->escape($event_initialView) . "' WHERE event_value_id = '1'");
		*/
	}

	public function getTestimonialsSetting() {
	/*	$query = $this->db->query("SELECT keyword as event FROM " . DB_PREFIX . "seo_url WHERE query = 'extension/module/event' LIMIT 1");
		$results_url['event']=$query->row['event'];
		
		$query = $this->db->query("SELECT keyword as list FROM " . DB_PREFIX . "seo_url WHERE query = 'extension/module/event_list' LIMIT 1");
		$results_url['list']=$query->row['list'];
		
		$query = $this->db->query("SELECT keyword as detail FROM " . DB_PREFIX . "seo_url WHERE query = 'extension/module/event_detail' LIMIT 1");
		$results_url['detail']=$query->row['detail'];
		
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "events_setting WHERE event_value_id ='1'");
		$results_setting=$query->row;
	
		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "setting` WHERE `code` = 'setting_module_genEvents' AND `key`='rightMenu'");

		if ($query->num_rows!=0){
		
			foreach ($query->rows as $result) {			
				$results_settingNameRightMenu[$result['key']] = json_decode($result['value'], true);			
			}
		} else{$results_settingNameRightMenu=array('rightMenu'=>'');}
		
		return array_merge($results_url, $results_setting,$results_settingNameRightMenu);*/
	}
	
	public function getValue() {
		
	/*	$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "events_setting WHERE `event_value_id`=1");

		return $query->row;*/
	}
	
	public function getValue2() {
		
	/*	$query = $this->db->query("SELECT value2 FROM " . DB_PREFIX . "events_setting WHERE `event_value_id`=1");
		$a=$query->row;

		return $a['value2'];*/
	}
	
	public function copyTestimonial($testimonial_id) {

	/*	$query = $this->db->query("SELECT DISTINCT * FROM " . DB_PREFIX . "events WHERE testimonial_id = '" . (int)$testimonial_id . "'");

		if ($query->num_rows) {
			$data = $query->row;
			
			$data['keyword'] = '';
			$data['status'] = '0';
			
			$data['event_color'] = $query->row["color"];

			$data['events_description'] = $this->getEventsDescriptions($testimonial_id);
			$data['license'] = $this->getValue2();
			$data['events_store'] = $this->getEventsStores($testimonial_id);

			$this->addEvents($data);
		}*/
	}
}
?>