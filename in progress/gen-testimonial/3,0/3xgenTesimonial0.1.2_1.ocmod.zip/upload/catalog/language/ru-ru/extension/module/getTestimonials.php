<?php
// Heading
$_['heading_title'] = 'Популярный продукт';

// Text
$_['text_tax']      = 'Без налога:';