<?php
namespace Opencart\Admin\Controller\Extension\GenModule\Module;
/**
 * Class Template Module
 *
 * @package Opencart\Admin\Controller\Extension\GenModule\Module
 */
class Events extends \Opencart\System\Engine\Controller {

	/**
	 * @return void
	 */
	public function install(): void {
		if ($this->user->hasPermission('modify', 'extension/gen_module/module/events')) {
			$this->load->model('extension/gen_module/module/events');

			$this->model_extension_gen_module_module_events->install();
		}
	}

	/**
	 * @return void
	 */
	public function uninstall(): void {
		if ($this->user->hasPermission('modify', 'extension/gen_module/module/events')) {
			$this->load->model('extension/gen_module/module/events');

			$this->model_extension_gen_module_module_events->uninstall();
		}
	}

	/**
	 * @return void
	 */
	public function index(): void {
		$this->load->model('extension/gen_module/module/events');
		$this->getList();
	}

	/**
	 * @return void
	 */
	public function getList(): void {

		$this->load->language('extension/gen_module/module/events');
		
		if (isset($this->request->get['sort'])) {
			$sort = (string)$this->request->get['sort'];
		} else {
			$sort = 'nd.title';
		}

		if (isset($this->request->get['order'])) {
			$order = (string)$this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = (int)$this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = [];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/gen_module/module/events', 'user_token=' . $this->session->data['user_token'] . $url),
			'separator' => ' :: '
		];

		//$data['action'] = $this->url->link('extension/gen_module/module/events.index', 'user_token=' . $this->session->data['user_token'] . $url);
		$events_setting = $this->model_extension_gen_module_module_events->getValue2();
		if ($events_setting){
			$data['add'] = $this->url->link('extension/gen_module/module/events/add', 'user_token=' . $this->session->data['user_token']);
			$data['delete'] = $this->url->link('extension/gen_module/module/events/delete', 'user_token=' . $this->session->data['user_token']);
			$data['copy'] = $this->url->link('extension/gen_module/module/events/copy', 'user_token=' . $this->session->data['user_token'] . $url);
			$data['hideEvent'] = $this->url->link('extension/gen_module/module/events/hideEvent', 'user_token=' . $this->session->data['user_token'] . $url);
		}else{
			$data['add'] = $this->url->link('extension/gen_module/module/events', 'user_token=' . $this->session->data['user_token']);
			$data['delete'] = $this->url->link('extension/gen_module/module/events', 'user_token=' . $this->session->data['user_token']);
			$data['copy'] = $this->url->link('extension/gen_module/module/events', 'user_token=' . $this->session->data['user_token'] . $url);
			$data['hideEvent'] = $this->url->link('extension/gen_module/module/events', 'user_token=' . $this->session->data['user_token'] . $url);
			//$data['error_warning'] = $this->language->get('error_license_setting');
		}



		$data['setting'] = $this->url->link('extension/gen_module/module/events/setting', 'user_token=' . $this->session->data['user_token'], true);
	
		$events_total = $this->model_extension_gen_module_module_events->getTotalEvents();
	
		$this->load->model('tool/image');
	
		$data['events'] = array();

		// var_dump($this->config->get('config_limit_admin'));die;
	
			$filter_data = array(
			'sort'  => $sort,
			'order' => $order,
			'start' => ($page - 1) * 10,
			'limit' => 10
		);

		$results = $this->model_extension_gen_module_module_events->getEventsList($filter_data);

    	foreach ($results as $result) {
		
			if ($result['image'] && file_exists(DIR_IMAGE . $result['image'])) {
				$image = $this->model_tool_image->resize($result['image'], 40, 40);
			} else {
				$image = $this->model_tool_image->resize('placeholder.png', 40, 40);
			}
		
			$data['events'][] = array(
				'event_id'     	=> $result['event_id'],
				'title'       	=> $result['title'],
				'image'      	=> $image,
				'date_from'  	=> date($this->language->get('date_format_short'), strtotime($result['date_from'])),
				'date_to'  	=> date($this->language->get('date_format_short'), strtotime($result['date_to'])),
				'status'     	=> ($result['status'] ? $this->language->get('text_enabled') : $this->language->get('text_disabled')),
				'selected'    	=> isset($this->request->post['selected']) && in_array($result['event_id'], $this->request->post['selected']),
				'edit'      	=> $this->url->link('extension/module/events/edit', 'user_token=' . $this->session->data['user_token'] . '&event_id=' . $result['event_id'], true)
			);
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_title'] = $this->url->link('extension/module/events', 'user_token=' . $this->session->data['user_token'] . '&sort=nd.title' . $url);
		$data['sort_date_to'] = $this->url->link('extension/module/events', 'user_token=' . $this->session->data['user_token'] . '&sort=n.date_to' . $url);

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$data['pagination'] = $this->load->controller('common/pagination', [
			'total' => $events_total,
			'page'  => $page,
			'limit' => $this->config->get('config_pagination_admin'),
			'url'   => $this->url->link('extension/gen_module/module/events.index', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}')
		]);

		$data['results'] = sprintf($this->language->get('text_pagination'), ($events_total) ? (($page - 1) * $this->config->get('config_pagination_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_pagination_admin')) > ($events_total - $this->config->get('config_pagination_admin'))) ? $events_total : ((($page - 1) * $this->config->get('config_pagination_admin')) + $this->config->get('config_pagination_admin')), $events_total, ceil($events_total / $this->config->get('config_pagination_admin')));

		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
	
		$this->response->setOutput($this->load->view('extension/gen_module/module/events_list', $data));

	}

	/**
	 * @return void
	 */
	public function setting() {	
		
		$this->load->language('extension/gen_module/module/events');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('extension/gen_module/module/events');
		$this->load->model('localisation/language');
		$val=$_SERVER['HTTP_HOST'];
		$val=strlen($val);

		$data['heading_title'] = $this->language->get('heading_title');

		$data['action'] = $this->url->link('extension/gen_module/module/events/setting', 'user_token=' . $this->session->data['user_token']);
		$data['cancel'] = $this->url->link('extension/gen_module/module/events', 'user_token=' . $this->session->data['user_token']);
	
		$data['breadcrumbs'] = array();
	
		$data['breadcrumbs'][] = array(
			'href'      => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token']),
			'text'      => $this->language->get('text_home'),
			'separator' => false
		);
	
		$data['breadcrumbs'][] = array(
			'href'      => $this->url->link('extension/gen_module/module/events', 'user_token=' . $this->session->data['user_token']),
			'text'      => $this->language->get('heading_title'),
			'separator' => ' :: '
		);

		$data['breadcrumbs'][] = array(
			'href'      => $this->url->link('extension/gen_module/module/events/setting', 'user_token=' . $this->session->data['user_token']),
			'text'      => $this->language->get('text_events_setting'),
			'separator' => ' :: '
		);	

		$setting = $this->model_extension_gen_module_module_events->getEventsSetting();
		
		$data['languages'] = $this->model_localisation_language->getLanguages();
		
		$data['rightMenu']=$setting['rightMenu'];		
		$data['days']=[
			1 => $data['Monday'],
			2 => $data['Tuesday'],
			3 => $data['Wednesday'],
			4 => $data['Thursday'],
			5 => $data['Friday'],
			6 => $data['Saturday'],
			7 => $data['Sunday']
		];
		
		$data['listOptions']=[
			'dayGridMonth'=>$data['dayGridMonth'],
			'timeGridWeek'=>$data['timeGridWeek'],
			'timeGridDay'=>$data['timeGridDay'],
			'listYear'=>$data['listYear'],
			'listMonth'=>$data['listMonth'],
			'listDay'=>$data['listDay'],
			'listWeek'=>$data['listWeek']
		];
		
		if(isset($setting['status'])){
			$data['status'] = $setting['status'];
		}else{
			$data['status'] = 0;
		}
		
		if($setting['event_share']){
			$data['event_share'] = $setting['event_share'];
		}else{
			$data['event_share'] = '';
		}
		
		if(isset($setting['event'])){
			$data['events_url'] = $setting['event'];
		}else{
			$data['events_url'] = '';
		}
	
		if(isset($setting['list'])){
			$data['eventslist_url'] = $setting['list'];
		}else{
			$data['eventslist_url'] = '';
		}
		
		if(isset($setting['detail'])){
			$data['eventsDetail_url'] = $setting['detail'];
		}else{
			$data['eventsDetail_url'] = '';
		}
		
		if(isset($setting['firstDay'])){
			$data['event_firstDays'] = $setting['firstDay'];
		}else{
			$data['event_firstDays'] = 1;
		}
		
		if(isset($setting['dayMaxEvents'])){
			$data['dayMaxEvents'] = $setting["dayMaxEvents"];
		}else{
			$data['dayMaxEvents'] = 0;
		}
		
		if(isset($setting['initialView'])){
			$data['initialView'] = $setting["initialView"];
		}else{
			$data['initialView'] = 'dayGridMonth';
		}
		
		if(isset($setting['rightColumnMenu'])){			
			$data['rightColumnMenu'] = explode(",", $setting['rightColumnMenu']);
		}else{
			$data['rightColumnMenu'] = array();
		}
		
		if(isset($setting['value'])){
			$data['value'] = $setting["value"];
		}else{
			$data['value'] = '';
		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		$this->response->setOutput($this->load->view('extension/gen_module/module/event_setting', $data));
	}

	/**
	 * @return void
	 */
	public function save(): void {
		$this->load->language('extension/gen_module/module/events');

		$json = [];

		if (!$this->user->hasPermission('modify', 'extension/gen_module/module/events')) {
			$json['error'] = $this->language->get('error_permission');
		}

		if (!$json) {
			$this->load->model('setting/setting');

			$this->model_setting_setting->editSetting('module_events', $this->request->post);

			$json['success'] = $this->language->get('text_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

		/**
	 * @return void
	 */
	public function saveSetting(): void {
		$this->load->language('extension/gen_module/module/events');

		$json = [];

		if (!$this->user->hasPermission('modify', 'extension/gen_module/module/events')) {
			$json['error'] = $this->language->get('error_permission');
		}

		if (!$json) {
			$this->load->model('extension/gen_module/module/events');

			$this->model_extension_gen_module_module_events->setEventsSetting($this->request->post);

			$json['success'] = $this->language->get('text_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
}