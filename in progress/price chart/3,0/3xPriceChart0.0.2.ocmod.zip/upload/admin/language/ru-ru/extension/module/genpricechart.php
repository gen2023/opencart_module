<?php
// Heading
$_['heading_title']				= 'График цен';

$_['entry_status']				= 'Статус';

$_['text_edit']				= 'Настройки модуля';
$_['text_success']				= 'Модуль изменен';
$_['text_extension']				= 'Расширения';
