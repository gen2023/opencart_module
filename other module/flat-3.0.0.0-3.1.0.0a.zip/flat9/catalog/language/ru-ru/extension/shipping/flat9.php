<?php
// Text
$_['text_title']       = 'Единая ставка';
$_['text_description'] = 'Фиксированная стоимость доставки 9';