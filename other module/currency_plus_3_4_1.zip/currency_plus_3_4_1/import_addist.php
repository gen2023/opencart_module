<?php
set_time_limit(0);

require_once('config.php'); 
require_once(DIR_SYSTEM . 'library/db.php');   
require_once(DIR_SYSTEM . 'library/db/mysqli.php');

$db = new DB(DB_DRIVER, DB_HOSTNAME, DB_USERNAME, DB_PASSWORD, DB_DATABASE);  // Database	


$query = $db->query("update " . DB_PREFIX . "product set currency='USD' WHERE currency='';");
$query = $db->query("update " . DB_PREFIX . "product set overhead_currency='USD' WHERE overhead_currency='';");

$query = $db->query("update " . DB_PREFIX . "product set base_price=price, base_currency_code=currency;");
$query = $db->query("update " . DB_PREFIX . "product set extra_charge=(margin+overheads*100/price);");

?>