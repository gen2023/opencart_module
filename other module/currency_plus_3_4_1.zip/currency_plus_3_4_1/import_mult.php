<?php
set_time_limit(0);

require_once('config.php'); 
require_once(DIR_SYSTEM . 'library/db.php');   
require_once(DIR_SYSTEM . 'library/db/mysqli.php');

$db = new DB(DB_DRIVER, DB_HOSTNAME, DB_USERNAME, DB_PASSWORD, DB_DATABASE);  // Database	

$query = $db->query("SELECT p.product_id, p.price, c.code from " . DB_PREFIX . "product_price p
inner join " . DB_PREFIX . "currency c on c.currency_id=p.currency_id WHERE p.price > 0 AND p.currency_id  > 0 ");

foreach ($query->rows as $result) {
    $sql2 = "UPDATE " . DB_PREFIX . "product SET base_currency_code='".$result['code']."', base_price='".$result['price']."' WHERE product_id='".$result['product_id']."' ";
   // echo $sql2."/n";
    $db->query($sql2);

}

?>