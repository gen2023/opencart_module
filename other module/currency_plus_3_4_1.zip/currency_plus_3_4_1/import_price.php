<?php
ini_set("display_errors","1");
ini_set("display_startup_errors","1");
ini_set('error_reporting', E_ALL);

set_time_limit(0);

require_once('config.php'); 
require_once(DIR_SYSTEM . 'library/db.php');   
require_once(DIR_SYSTEM . 'library/db/mysqli.php');

$valuta = 'USD';
//$currency = '73.42389679';
$currency = '1';

$db = new DB(DB_DRIVER, DB_HOSTNAME, DB_USERNAME, DB_PASSWORD, DB_DATABASE);  // Database	

//$db->query("update " . DB_PREFIX . "product set price= base_price * 66.34120178");


$db->query("update " . DB_PREFIX . "product set base_price=price/".$currency.";");

$db->query("update " . DB_PREFIX . "product_option_value set base_price=price/".$currency.";");

$db->query("update " . DB_PREFIX . "product_discount set base_price=price/".$currency.";");

$db->query("update " . DB_PREFIX . "product_special set base_price=price/".$currency.";");

$db->query("update " . DB_PREFIX . "product set base_currency_code='".$valuta."';");

?>