<?php
//Text
$_['text_model'] = 'Модель:';

//Button
$_['button_all'] = 'Показать все результаты';