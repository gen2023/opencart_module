<?php
//Text
$_['text_model'] = 'Model:';

//Button
$_['button_all'] = 'Show all results';