<?php 

$_['title_payment_address']  						= 'Данные клиента';
$_['description_payment_address']  					= '';
$_['title_shipping_address']  						= 'Данные получателя';
$_['description_shipping_address'] 					= '';
$_['title_shipping_method']  						= 'Способ доставки';
$_['description_shipping_method'] 					= '';
$_['title_payment_method'] 							= 'Способ оплаты';
$_['description_payment_method'] 					= '';
$_['title_shopping_cart'] 							= 'Корзина заказа';
$_['description_shopping_сart'] 					= '';


$_['placeholder_telephone'] 						= 'Номер телефона';

$_['error_field_required'] 							= 'Заполните поле!';
$_['error_valid_telephone'] 						= 'Введите правильный номер телефона';
$_['entry_email_confirm'] 							= 'Подтвердить Email';
$_['error_email_confirm'] 							= 'Email не совпадает!';


$_['step_option_guest_desciption'] = 'Используйте гостевой аккаунт, чтобы покупать без регистрации';

$_['error_step_payment_address_fields_company'] = 'Название компании должно содержать от 3 до 128 символов';
$_['error_step_shipping_address_fields_company'] = 'Название компании должно содержать от 3 до 128 символов';

$_['error_step_confirm_fields_comment'] = 'Пожалуйста, оставьте свой комментарий к заказу';


?>