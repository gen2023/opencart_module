<?php

// Entry
$_['entry_email']          = 'E-Mail';
$_['entry_telephone']      = 'Telephone';
