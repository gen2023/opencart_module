<?php
// Heading
$_['heading_title']     = 'Подписаться на рассылку';
$_['name']     			= 'Ваше имя:';
$_['town']     			= 'Ваш город';
$_['error_email']     	= 'Неправильный Email';
$_['error_town']    	= 'Заполните поле город';
$_['error_name']   		= 'Заполните поле имя';
$_['error_email2']     	= 'Заполните поле Email';
$_['but_newsletter'] 	= 'Подписаться';
$_['text_success'] 	= 'Вы успешно подписались на рассылку';
$_['text_error'] 	= 'Ошибка подписки';
$_['text_dublicate'] 	= 'Этот Email уже есть в подписчиках';

