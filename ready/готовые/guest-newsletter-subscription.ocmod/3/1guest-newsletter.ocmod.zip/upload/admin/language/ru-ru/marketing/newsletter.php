<?php
// header
$_['heading_title']    = 'Подписчики';

// Text
$_['text_list']    = 'Список подписчиков';

//column
$_['column_name']     = 'Имя';
$_['column_town']   = 'Город';
