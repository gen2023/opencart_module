<?php
// Heading
$_['heading_title']  = 'Підписатися на розсилку';
$_['name']			 = 'Ваше ім`я:';
$_['town']			 = 'Ваше місто';
$_['error_email'] 	 = 'Невірний Email';
$_['error_town'] 	 = 'Заповніть поле місто';
$_['error_name'] 	 = 'Заповніть поле ім`я';
$_['error_email2'] 	 = 'Заповніть поле Email';
$_['but_newsletter'] = 'Підписатися';