<?php
class ControllerExtensionModuleNewsletters extends Controller {
	public function index() {
		$this->load->language('extension/module/newsletter');
		$this->load->model('extension/module/newsletters');
		
		$this->model_extension_module_newsletters->createNewsletter();

		$data['heading_title'] = $this->language->get('heading_title');
		$data['name'] = $this->language->get('name');
		$data['town'] = $this->language->get('town');
		$data['error_email'] = $this->language->get('error_email');
		$data['error_town'] = $this->language->get('error_town');
		$data['error_name'] = $this->language->get('error_name');
		$data['error_email2'] = $this->language->get('error_email2');
		$data['but_newsletter'] = $this->language->get('but_newsletter');
		
		return $this->load->view('extension/module/newsletters', $data);
	}
	public function news()
	{
		$this->load->model('extension/module/newsletters');
		
		$json = array();
		$json['message'] = $this->model_extension_module_newsletters->subscribes($this->request->post);
		
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
		
	}
	
}
