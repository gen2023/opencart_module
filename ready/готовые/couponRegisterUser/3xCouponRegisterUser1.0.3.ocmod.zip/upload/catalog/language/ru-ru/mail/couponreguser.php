<?php
// Text
$_['text_subject']        = '%s - Благодарим за регистрацию';
