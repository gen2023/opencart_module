<?php
// Text
$_['text_subject']        = '%s - Thank you for registering';
