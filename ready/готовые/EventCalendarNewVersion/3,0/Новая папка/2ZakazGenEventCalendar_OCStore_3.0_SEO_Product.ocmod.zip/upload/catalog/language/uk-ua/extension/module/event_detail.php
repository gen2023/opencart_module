<?php

// Text
$_['text_search']                             = 'Пошук';

// breadcrumbs
$_['event'] = 'Події на календарі';
$_['event_list'] = 'Список всіх подій';