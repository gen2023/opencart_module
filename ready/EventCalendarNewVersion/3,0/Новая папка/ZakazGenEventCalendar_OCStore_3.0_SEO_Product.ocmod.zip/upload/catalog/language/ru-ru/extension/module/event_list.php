<?php

$_['heading_title']   		= 'Список всех событий';

// Text
$_['text_more']  			= 'Подробнее';
$_['text_sort']         	= 'Сортировать:';
$_['text_default']      	= 'По умолчанию';
$_['text_title_asc']     	= 'По Названию (A - Я)';
$_['text_title_desc']    	= 'По Названию (Я - A)';
$_['text_date_asc']   		= 'По Дате (возрастанию)';
$_['text_date_desc']  		= 'По Дате (убыванию)';
$_['text_limit']        	= 'Показывать:';

$_['event_date_from'] = " по дату ";
$_['event_date_to'] = "C даты ";
