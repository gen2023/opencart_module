<?php
// Heading
$_['heading_title']    = 'Виды работ';

// Text
$_['text_extension']   = 'Расширения';
$_['text_success']     = 'Настройки успешно изменены!';
$_['text_edit']        = 'Настройки модуля';
$_['text_day']          = 'Дни';
$_['text_month']          = 'Месяцы';

//Entry
$_['entry_nameTypeWork']          = 'Название';
$_['entry_month_start']          = 'Начало';
$_['entry_month_end']          = 'конец';
$_['entry_color']          = 'Цвет';
$_['entry_viewTypeX']          = 'Ось Х';
$_['entry_sort_order']          = 'Сортировка';
$_['entry_time1']          = 'Начать загрузку скрипта через н сек, после доскроливания(5)';
$_['entry_time2']          = 'Начать загрузку скрипта через н сек(5)';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'У Вас нет прав для изменения модуля Аккаунт!';

//Tab
$_['tab_typeWork']          = 'Виды работ';
