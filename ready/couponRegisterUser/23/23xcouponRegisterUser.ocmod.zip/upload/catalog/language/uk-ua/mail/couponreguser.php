<?php
// Text
$_['text_subject']        = '%s - Дякуємо за реєстрацію';
