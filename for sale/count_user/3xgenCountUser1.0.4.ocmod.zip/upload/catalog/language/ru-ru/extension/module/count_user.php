<?php 

$_['text_current_day']= 'Сегодня:';
$_['text_all_day']= 'за все время:';