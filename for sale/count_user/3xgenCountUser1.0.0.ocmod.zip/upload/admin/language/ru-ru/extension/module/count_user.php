<?php
$_['heading_title']    = 'Статистика пользователей';

$_['text_module']      = 'Модули';
$_['text_edit']        = 'Настройки модуля';
$_['text_success']     = 'Настройки модуля обновлены';
$_['text_current']      = 'Сегодня';
$_['text_yesterday']      = 'Вчера';
$_['text_week']      = 'За неделю';
$_['total_month']      = 'За месяц';
$_['total_year']      = 'За год';
$_['total_all']      = 'Всего';
$_['table_statistic_title']      = 'Статистика';


$_['entry_status']     = 'Статус';