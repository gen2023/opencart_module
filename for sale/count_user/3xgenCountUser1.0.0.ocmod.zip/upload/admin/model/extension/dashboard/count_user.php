<?php
class ModelExtensionDashboardCountUser extends Model {
	
}