<?php

$_['text_current_day']= 'Today:';
$_['text_all_day']= 'all time:';