<?php
class ModelExtensionModuleGenFilterProduct extends Model {
	
	public function install() {
		
		$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "gen_product_filter` (`id` int(11) NOT NULL auto_increment, `allPage` int(11) COLLATE utf8_general_ci default 0, `addressD` VARCHAR(255) COLLATE utf8_general_ci default NULL, `seriaD` VARCHAR(255) COLLATE utf8_general_ci default NULL, `floor` int(11) COLLATE utf8_general_ci default 0, `yearD` int(11) COLLATE utf8_general_ci default 0, `typeD` VARCHAR(255) COLLATE utf8_general_ci default NULL,`product_id` int(11) COLLATE utf8_general_ci default 0, PRIMARY KEY (`id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci");			
		
	}

	public function uninstall() { 
		$this->db->query("DROP TABLE `" . DB_PREFIX . "gen_product_filter`");
	}
	
	/*public function getTotal() {
		$sql = "SELECT COUNT(*) AS total FROM `" . DB_PREFIX . "gen_count_user` WHERE `allPage`=1";

		$query = $this->db->query($sql);

		return $query->row['total'];
	}
	public function getTotalOnline() {
		$sql = "SELECT * FROM `" . DB_PREFIX . "gen_count_user` WHERE `allPage`=1";
		$query = $this->db->query($sql);

		return $query->rows;
	}*/

	
}
?>