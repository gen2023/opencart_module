<?php
// header
$_['heading_title'] = 'Address filter';
$_['text_table_name'] = 'Address';
$_['text_table_series'] = 'Series';
$_['text_table_floor'] = 'Floor';
$_['text_table_year'] = 'Year';
$_['text_table_type'] = 'Type';