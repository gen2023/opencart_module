<?php  
class ControllerExtensionModuleTipDoma extends Controller {
	public function index() {

		$this->load->language('extension/module/gen_filter_product'); 
		$this->load->model('extension/module/gen_filter_product');
		$data['heading_title'] = $this->language->get('heading_title'); 
		

		$results = $this->model_extension_module_gen_filter_product->getProductAdressD($this->request->get['product_id']);


		$data['homes'] = array();

		foreach ($results as $result) {
			$data['homes'][] = array(
				'addressD'          => $result['addressD'],
				'seriaD'          => $result['seriaD'],
				'floorD'             => $result['floorD'],
				'yearD'        => $result['yearD'],
				'typeD'          => $result['typeD']
			);
		}
      	//echo "<pre>";var_dump($data['homes']);echo "</pre>";

		$data['column_left'] = $this->load->controller('common/column_left');
		$data['column_right'] = $this->load->controller('common/column_right');
		$data['content_top'] = $this->load->controller('common/content_top');
		$data['content_bottom'] = $this->load->controller('common/content_bottom');
		$data['footer'] = $this->load->controller('common/footer');
		$data['header'] = $this->load->controller('common/header');
		//var_dump($data['products']);
		$this->response->setOutput($this->load->view('extension/module/tip_doma', $data));
	}
}
