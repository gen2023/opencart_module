<?php
// Heading
$_['heading_title'] = 'Фильтр адресов';
$_['text_table_name'] = 'Адрес';
$_['text_table_series'] = 'Серия';
$_['text_table_floor'] = 'Этаж';
$_['text_table_year'] = 'Год';
$_['text_table_type'] = 'Тип';