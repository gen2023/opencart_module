<?php

$ _ [ 'heading_title'] = 'Список всіх подій';

// Text
$_['text_more'] = 'Детальніше';
$_['text_sort'] = 'Сортувати:';
$_['text_default'] = 'За замовчуванням';
$_['text_title_asc'] = 'За Назвою (A - Я)';
$_['text_title_desc'] = 'За Назвою (Я - A)';
$_['text_date_to_asc']   		= 'За датою початку події (зростанню)';
$_['text_date_to_desc']  		= 'За датою початку події (зменшенням)';
$_['text_date_from_asc']   		= 'За датою кінця події (зростанню)';
$_['text_date_from_desc']  		= 'За датою кінця події (зменшенням)';
$_['text_doctor_asc'] = 'За лектором (A - Я)';
$_['text_doctor_desc'] = 'За лектором (Я - A)';
$_['text_limit'] = 'Показувати:';

$_['event_date_from'] = " по дату ";
$_['event_date_to'] = "З дати ";