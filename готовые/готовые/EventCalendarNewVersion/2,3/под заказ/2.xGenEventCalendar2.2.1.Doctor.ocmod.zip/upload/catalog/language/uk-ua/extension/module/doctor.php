<?php
$_['heading_title'] = 'Список активних лекторів';

$_['text_name_asc'] = 'На ім`я (A - Я)';
$_['text_name_desc'] = 'На ім`я (Я - A)';
$_['text_sort'] = 'Сортувати:';
$_['text_limit'] = 'Показувати:';
$_['text_more'] = 'Детальніше';
$_['doctor_list']  			= 'Список всіх лекторів