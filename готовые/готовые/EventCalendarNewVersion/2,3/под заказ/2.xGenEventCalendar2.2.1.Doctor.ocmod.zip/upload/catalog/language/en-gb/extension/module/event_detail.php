<?php

// Text
$_['text_search']                             = 'Search';
$_['text_error'] = 'Category not found!';

// breadcrumbs
$_['event'] = 'Events on the calendar';
$_['event_list'] = 'List of all events';
$_['event_date_from'] = " to date ";
$_['event_date_to'] = "Date";
$_['event_time_to'] = "Time";
$_['event_price'] = "Price";