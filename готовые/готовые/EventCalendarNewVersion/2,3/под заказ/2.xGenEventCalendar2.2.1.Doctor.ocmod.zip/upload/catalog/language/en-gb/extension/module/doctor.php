<?php
$_['heading_title'] = 'List of Active Lecturers';

$_['text_name_asc'] = 'By name (A - Z)';
$_['text_name_desc'] = 'By name (Me - A)';
$_['text_sort'] = 'Sort:';
$_['text_limit'] = 'Show:';
$_['text_more'] = 'More details';
$_['doctor_list']  			= 'List of all lecturers';