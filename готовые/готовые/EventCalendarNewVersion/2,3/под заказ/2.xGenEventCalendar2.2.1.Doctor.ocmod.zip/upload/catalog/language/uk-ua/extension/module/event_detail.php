<?php

// Text
$_['text_search']                             = 'Пошук';

// breadcrumbs
$_['event'] = 'Події на календарі';
$_['event_list'] = 'Список всіх подій';
$_['event_date_from'] = " по дату ";
$_['event_date_to'] = "Дата";
$_['event_time_from'] = " по ";
$_['event_time_to'] = "Час";
$_['event_price'] = "Ціна";