<?php

$_['heading_title']   		= 'Список всех событий';

// Text
$_['text_more']  			= 'Подробнее';
$_['text_sort']         	= 'Сортировать:';
$_['text_default']      	= 'По умолчанию';
$_['text_title_asc']     	= 'По названию (A - Я)';
$_['text_title_desc']    	= 'По названию (Я - A)';
$_['text_date_to_asc']   		= 'По дате начала события (возрастанию)';
$_['text_date_to_desc']  		= 'По дате начала события (убыванию)';
$_['text_date_from_asc']   		= 'По дате конца события (возрастанию)';
$_['text_date_from_desc']  		= 'По дате конца события (убыванию)';
$_['text_doctor_asc']   		= 'По лектору (возрастанию)';
$_['text_doctor_desc']  		= 'По лектору (убыванию)';
$_['text_limit']        	= 'Показывать:';

$_['event_date_from'] = " по дату ";
$_['event_date_to'] = "C даты ";
