<?php
		$create_events = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "events` (`event_id` int(11) NOT NULL auto_increment, `status` int(1) NOT NULL default '0', `image` VARCHAR(255) COLLATE utf8_general_ci default NULL, `date_from` date default NULL, `date_to` date NOT NULL, `time_to` varchar(255) NOT NULL, `sort_order` int(11) NOT NULL DEFAULT '0', PRIMARY KEY (`event_id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci";
		$this->db->query($create_events);
	
		$create_event_descriptions = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "event_description` ( `event_id` int(11) NOT NULL  default '0', `language_id` int(11) NOT NULL  default '0', `title` varchar(165) NOT NULL, `mindescription` varchar(255) NOT NULL, `description` longtext NOT NULL, PRIMARY KEY (`event_id`,`language_id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci";
		$this->db->query($create_event_descriptions);

		$create_event_value = "CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "event_value` ( `event_value_id` int(11) NOT NULL  auto_increment, `value2` varchar(8) NOT NULL, `value1` varchar(165) NOT NULL, PRIMARY KEY (`event_value_id`)) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci";
		$this->db->query($create_event_value);
		
		$insert_event_value = "INSERT INTO " . DB_PREFIX . "event_value SET value1 = '26028713', value2 = ''";
		$this->db->query($insert_event_value);
?>
  