<?php
// Heading
$_['heading_title']          = 'Общие настройки';

// Text
$_['text_success']           = 'Успех: вы изменили события!';
$_['text_setting']           = 'Настройки SEO URL модуля';

$_['entry_keyword_list']          	= 'SEO URL для страницы event_list:';
$_['entry_keyword_detail']          	= 'SEO URL для страницы event_detail:';
$_['entry_keyword_event']          	= 'SEO URL для страницы event:';
$_['entry_keyword']          	= 'SEO URL:';

// Помощь
$_['help_keyword']          	= 'Используйте тире вместо пробелов. Должно быть уникально на всю систему';

// Ошибка

$_['error_warning'] = 'Предупреждение: пожалуйста, внимательно проверьте форму на наличие ошибок!';
$_['error_permission'] = 'Предупреждение: у вас нет прав на изменение событий!';
$_['error_keyword']          	= 'Этот SEO keyword уже используется!';

