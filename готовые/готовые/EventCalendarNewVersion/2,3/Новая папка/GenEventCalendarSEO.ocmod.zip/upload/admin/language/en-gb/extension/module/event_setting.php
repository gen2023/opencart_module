<?php
// Heading
$_['heading_title'] = 'General Settings';

// Text
$_['text_success'] = 'Success: you changed events!';
$_['text_setting'] = 'SEO settings module URL';

$_['entry_keyword_list'] = 'SEO URL for event_page:';
$_['entry_keyword_event'] = 'SEO URL for event page:';
$_['entry_keyword'] = 'SEO URL:';

// Help
$_['help_keyword'] = 'Use dashes instead of spaces. Must be unique to the whole system ';

// Mistake

$_['error_warning'] = 'Warning: please carefully check the form for errors!';
$_['error_permission'] = 'Warning: you do not have permission to modify events!';
$_['error_keyword'] = 'This SEO keyword is already in use!';