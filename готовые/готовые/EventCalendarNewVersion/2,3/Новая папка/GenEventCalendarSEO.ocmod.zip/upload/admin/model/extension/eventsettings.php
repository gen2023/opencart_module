<?php
class ModelExtensionEventsettings extends Model {

    public function addEvent($data) {

	   if (isset($data['keyword'])) {
			$this->db->query("INSERT INTO " . DB_PREFIX . "url_alias SET query = 'event_id=" . (int)$event_id . "', keyword = '" . $this->db->escape($data['keyword']) . "'");
		}

		return $this->db->getLastId();
	}

	public function KeywordEvent() {

		$query = $this->db->query("SELECT keyword FROM " . DB_PREFIX . "url_alias WHERE query = 'extension/module/event' LIMIT 1");
		$data[0]=$query->row;
		
		$query = $this->db->query("SELECT keyword FROM " . DB_PREFIX . "url_alias WHERE query = 'extension/module/event_list' LIMIT 1");
		$data[1]=$query->row;
		
		$query = $this->db->query("SELECT keyword FROM " . DB_PREFIX . "url_alias WHERE query = 'extension/module/event_detail' LIMIT 1");
		$data[2]=$query->row;
		
		return $data;
	}		
	
	public function editKeyEvent($data) {
		
		$this->db->query("DELETE FROM " . DB_PREFIX . "url_alias WHERE query = 'extension/module/event_list'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "url_alias WHERE query = 'extension/module/event'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "url_alias WHERE query = 'extension/module/event_detail'");
		
		if ($data) {
			$this->db->query("INSERT INTO " . DB_PREFIX . "url_alias SET query = 'extension/module/event', keyword = '" . $this->db->escape($data['keyword_event']) . "'");
			$this->db->query("INSERT INTO " . DB_PREFIX . "url_alias SET query = 'extension/module/event_list', keyword = '" . $this->db->escape($data['keyword_list']) . "'");
			$this->db->query("INSERT INTO " . DB_PREFIX . "url_alias SET query = 'extension/module/event_detail', keyword = '" . $this->db->escape($data['keyword_detail']) . "'");
		}
	}
	
}