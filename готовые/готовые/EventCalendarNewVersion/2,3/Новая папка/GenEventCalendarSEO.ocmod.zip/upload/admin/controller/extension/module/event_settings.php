<?php
class ControllerExtensionModuleEventSettings extends Controller {
	private $error = array();

   	public function index() {
		$this->load->language('extension/module/event_setting');

		$this->document->setTitle($this->language->get('heading_title'));
		
		$this->load->model('extension/eventsettings');
		
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) { 
		
			$this->model_extension_eventsettings->editKeyEvent($this->request->post);     
 
			$this->session->data['success'] = $this->language->get('text_success'); 
			
			//$this->redirect($this->url->link('extension/module/events', 'token=' . $this->session->data['token'], 'SSL')); 
		}
		
		
		
		// $this->setting();
	// }

	// protected function setting() {

		$data['heading_title'] = $this->language->get('heading_title');
		
		$data['text_form'] = !isset($this->request->get['id']) ? $this->language->get('text_setting') : $this->language->get('text_edit');
		
		$data['entry_keyword_list'] = $this->language->get('entry_keyword_list');
		$data['entry_keyword'] = $this->language->get('entry_keyword');		
		$data['entry_keyword_event'] = $this->language->get('entry_keyword_event');
		$data['entry_keyword_detail'] = $this->language->get('entry_keyword_detail');		

		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');
		$data['button_remove'] = $this->language->get('button_remove');

		$data['tab_general'] = $this->language->get('tab_general');
		
		$data['help_keyword'] = $this->language->get('help_keyword');
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		
		if (isset($this->error['keyword_event'])) {
			$data['error_keyword'] = $this->error['keyword_event'];
		} else {
			$data['error_keyword'] = '';
		}
		
		if (isset($this->error['keyword_list'])) {
			$data['error_keyword'] = $this->error['keyword_list'];
		} else {
			$data['error_keyword'] = '';
		}
		
		if (isset($this->error['keyword_detail'])) {
			$data['error_keyword'] = $this->error['keyword_detail'];
		} else {
			$data['error_keyword'] = '';
		}

		$url = '';

		if (isset($this->request->get['filter_name'])) {
			$url .= '&filter_name=' . urlencode(html_entity_decode($this->request->get['filter_name'], ENT_QUOTES, 'UTF-8'));
		}

		if (isset($this->request->get['filter_status'])) {
			$url .= '&filter_status=' . $this->request->get['filter_status'];
		}

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/module/event_settings', 'token=' . $this->session->data['token'] . $url, 'SSL')
		);
		
		$data['action'] = $this->url->link('extension/module/event_settings', 'token=' . $this->session->data['token'] . $url, 'SSL');

		$data['cancel'] = $this->url->link('extension/module/events', 'token=' . $this->session->data['token'] . $url, 'SSL');
		
		//$this->load->model('extension/eventsettings');
		
		//if ($this->request->server['REQUEST_METHOD'] != 'POST') {
			$seo = $this->model_extension_eventsettings->KeywordEvent();
			//$seo_eventlist = $this->model_extension_eventsettings->KeywordEventList();
		//}
	//var_dump($seo);
	//var_dump($seo_eventlist);
	
		$seo_event=$seo[0];
		$seo_eventlist=$seo[1];
		$seo_eventdetail=$seo[2];
		
		$data['token'] = $this->session->data['token'];
		
		
		$this->load->model('localisation/language');

		$data['languages'] = $this->model_localisation_language->getLanguages();
		
		$data['lang'] = $this->language->get('lang');
/*редактирование события*/		
		if (isset($this->request->post['keyword_event'])) {
			$data['keyword_event'] = $this->request->post['keyword_event'];
		} elseif (!empty($seo_event)) {
			$data['keyword_event'] = $seo_event['keyword'];
		} else {
			$data['keyword_event'] = '';
		}
		
		if (isset($this->request->post['keyword_list'])) {
			$data['keyword_list'] = $this->request->post['keyword_list'];
		} elseif (!empty($seo_eventlist)) {
			$data['keyword_list'] = $seo_eventlist['keyword'];
		} else {
			$data['keyword_list'] = '';
		}
		
		if (isset($this->request->post['keyword_detail'])) {
			$data['keyword_detail'] = $this->request->post['keyword_detail'];
		} elseif (!empty($seo_eventlist)) {
			$data['keyword_detail'] = $seo_eventdetail['keyword'];
		} else {
			$data['keyword_detail'] = '';
		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/module/event_settings.tpl', $data));
	}

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'extension/module/event_settings')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if (utf8_strlen($this->request->post['keyword_event']) > 0) {
			$this->load->model('catalog/url_alias');

			$url_alias_info = $this->model_catalog_url_alias->getUrlAlias($this->request->post['keyword_event']);

			if ($url_alias_info && isset($this->request->get['event_id']) && $url_alias_info['query'] != 'event_id=' . $this->request->get['event_id']) {
				$this->error['keyword_event'] = sprintf($this->language->get('error_keyword'));
			}

			if ($url_alias_info && !isset($this->request->get['event_id'])) {
				$this->error['keyword_event'] = sprintf($this->language->get('error_keyword'));
			}
		}
		
		if (utf8_strlen($this->request->post['keyword_list']) > 0) {
			$this->load->model('catalog/url_alias');

			$url_alias_info = $this->model_catalog_url_alias->getUrlAlias($this->request->post['keyword_list']);

			if ($url_alias_info && isset($this->request->get['event_id']) && $url_alias_info['query'] != 'event_id=' . $this->request->get['event_id']) {
				$this->error['keyword_list'] = sprintf($this->language->get('error_keyword'));
			}

			if ($url_alias_info && !isset($this->request->get['event_id'])) {
				$this->error['keyword_list'] = sprintf($this->language->get('error_keyword'));
			}
		}
		
		if (utf8_strlen($this->request->post['keyword_detail']) > 0) {
			$this->load->model('catalog/url_alias');

			$url_alias_info = $this->model_catalog_url_alias->getUrlAlias($this->request->post['keyword_detail']);

			if ($url_alias_info && isset($this->request->get['event_id']) && $url_alias_info['query'] != 'event_id=' . $this->request->get['event_id']) {
				$this->error['keyword_detail'] = sprintf($this->language->get('error_keyword'));
			}

			if ($url_alias_info && !isset($this->request->get['event_id'])) {
				$this->error['keyword_detail'] = sprintf($this->language->get('error_keyword'));
			}
		}

		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}

		return !$this->error;
	}
	
}