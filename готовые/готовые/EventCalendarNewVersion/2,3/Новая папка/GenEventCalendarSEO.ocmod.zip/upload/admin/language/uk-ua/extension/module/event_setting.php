<?php
// Heading
$_['heading_title'] = 'Загальні настройки';

// Text
$_['text_success'] = 'Успіх: ви змінили події!';
$_['text_setting'] = 'Налаштування SEO URL модуля';

$_['entry_keyword_list'] = 'SEO URL для сторінки event_list:';
$_['entry_keyword_event'] = 'SEO URL для сторінки event:';
$_['entry_keyword'] = 'SEO URL:';

// Допомога
$_['help_keyword'] = 'Використовуйте тире замість пробілів. Повинно бути унікально на всю систему ';

// Помилка

$_['error_warning'] = 'Попередження: будь ласка, уважно перевірте форму на наявність помилок!';
$_['error_permission'] = 'Попередження: у вас немає прав на зміну подій!';
$_['error_keyword'] = 'Цей SEO keyword вже використовується!';