<?php
class ModelExtensionEvents extends Model {

    public function addEvent($data) {

	   $this->db->query("UPDATE " . DB_PREFIX . "event_value SET value2 = '" . $this->db->escape($data['license']) . "' WHERE event_value_id = '1'");
	   
		$this->db->query("INSERT INTO " . DB_PREFIX . "events SET date_from = '" . $this->db->escape(date('Y-m-d',strtotime($data['date_from']))) ."', date_to = '" . $this->db->escape(date('Y-m-d',strtotime($data['date_to']))) . "', time_to = '" . $this->db->escape($data['time_to']) . "', status = '" . $this->db->escape($data['status']) . "', sort_order = '" . (int)$data['sort_order'] . "'");
		
		$event_id = $this->db->getLastId();
		
		if (isset($data['image'])) {
			$this->db->query("UPDATE " . DB_PREFIX . "events SET image = '" . $this->db->escape($data['image']) . "' WHERE event_id = '" . (int)$event_id . "'");
		}
		
		foreach ($data['event_description'] as $language_id => $value) {			 
			$this->db->query("INSERT INTO " . DB_PREFIX . "event_description SET event_id = '" . (int)$event_id . "', language_id = '" . (int)$language_id . "',title = '" . $this->db->escape($value['title']) . "', mindescription = '" . $this->db->escape($value['mindescription']) . "', description = '" . $this->db->escape($value['description']) . "'");
		}

		
		//$this->cache->delete('events');

		return $this->db->getLastId();
	}

	public function editEvent($event_id, $data) {

		$this->db->query("UPDATE " . DB_PREFIX . "events SET date_from = '" . $this->db->escape(date('Y-m-d',strtotime($data['date_from']))) ."', date_to = '" . $this->db->escape(date('Y-m-d',strtotime($data['date_to']))) . "', time_to = '" . $this->db->escape($data['time_to']) . "', status = '" . $this->db->escape($data['status']) . "', sort_order = '" . (int)$data['sort_order'] . "' WHERE event_id = '" . (int)$event_id . "'");
		
		if (isset($data['image'])) {
			$this->db->query("UPDATE " . DB_PREFIX . "events SET image = '" . $this->db->escape($data['image']) . "' WHERE event_id = '" . (int)$event_id . "'");
		}
		$this->db->query("DELETE FROM " . DB_PREFIX . "event_description WHERE event_id = '" . (int)$event_id . "'");
		//var_dump($data['event_description']);
		foreach ($data['event_description'] as $language_id => $value) {			 
			$this->db->query("INSERT INTO " . DB_PREFIX . "event_description SET event_id = '" . (int)$event_id . "', language_id = '" . (int)$language_id . "',title = '" . $this->db->escape($value['title']) . "', mindescription = '" . $this->db->escape($value['mindescription']) . "', description = '" . $this->db->escape($value['description']) . "'");
		}
		
		$this->cache->delete('events');
	}

	public function deleteEvent($event_id) {
		$this->db->query("DELETE FROM " . DB_PREFIX . "events WHERE event_id = '" . (int)$event_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "event_description WHERE event_id = '" . (int)$event_id . "'");
		$this->cache->delete('events');
	}

	public function getEvent($event_id) {
		$query = $this->db->query("SELECT *, (SELECT keyword FROM " . DB_PREFIX . "url_alias WHERE query = 'event_id=" . (int)$event_id . "' LIMIT 1) AS keyword FROM " . DB_PREFIX . "events WHERE event_id = '" . (int)$event_id . "'");

		return $query->row;
	}

	public function getEvents($data = array()) {
		if ($data) {
			$sql = "SELECT * FROM " . DB_PREFIX . "events i LEFT JOIN " . DB_PREFIX . "event_description id ON (i.event_id = id.event_id) WHERE id.language_id = '" . (int)$this->config->get('config_language_id') . "'";

			$sort_data = array(
				'id.title',
				'i.sort_order'
			);

			if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
				$sql .= " ORDER BY " . $data['sort'];
			} else {
				$sql .= " ORDER BY id.title";
			}

			if (isset($data['order']) && ($data['order'] == 'DESC')) {
				$sql .= " DESC";
			} else {
				$sql .= " ASC";
			}

			if (isset($data['start']) || isset($data['limit'])) {
				if ($data['start'] < 0) {
					$data['start'] = 0;
				}

				if ($data['limit'] < 1) {
					$data['limit'] = 20;
				}

				$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
			}

			$query = $this->db->query($sql);

			return $query->rows;
		} else {
			$event_data = $this->cache->get('event.' . (int)$this->config->get('config_language_id'));

			if (!$event_data) {
				$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "event i LEFT JOIN " . DB_PREFIX . "event_description id ON (i.event_id = id.event_id) WHERE id.language_id = '" . (int)$this->config->get('config_language_id') . "' ORDER BY id.title");

				$event_data = $query->rows;

				$this->cache->set('event.' . (int)$this->config->get('config_language_id'), $event_data);
			}

			return $event_data;
		}
	}
	
	public function getEventDescriptions($event_id) {
		
		//$event_id=42;
		$event_description_data = array();

		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "event_description WHERE event_id = '" . (int)$event_id . "'");

		foreach ($query->rows as $result) {
			$event_description_data[$result['language_id']] = array(
				'title'      => $result['title'],
				'mindescription'      => $result['mindescription'],
				'description'      => $result['description']
			);
		}
		//var_dump($event_description_data);
		return $event_description_data;
	}
	
	public function getTotalEvents() {
		
		$query = $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "events");


		return $query->row['total'];
	}
	
	public function getValue() {
		
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "event_value WHERE `event_value_id`=1");


		return $query->row;
	}
	
	
}