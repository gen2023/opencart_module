<?php

$_['heading_title'] = 'List of all events';

// Text
$_['text_more'] = 'Details';
$_['text_sort'] = 'Sort:';
$_['text_default'] = 'Default';
$_['text_title_asc'] = 'By Name (A - Z)';
$_['text_title_desc'] = 'By Name (I - A)';
$_['text_date_to_asc'] = 'By event start date (Ascending)';
$_['text_date_to_desc'] = 'By event start date (Descending)';
$_['text_date_from_asc'] = 'By event end date (Ascending)';
$_['text_date_from_desc'] = 'By event end date (descending)';
$_['text_limit'] = 'Show:';

$_['event_date_from'] = " to date ";
$_['event_date_to'] = "From date ";
$_['event'] = 'Events on the calendar';