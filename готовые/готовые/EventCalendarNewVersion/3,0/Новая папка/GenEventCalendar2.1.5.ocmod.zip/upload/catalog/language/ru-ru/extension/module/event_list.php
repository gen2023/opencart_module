<?php

$_['heading_title']   		= 'Список всех событий';

// Text
$_['text_more']  			= 'Подробнее';
$_['text_sort']         	= 'Сортировать:';
$_['text_default']      	= 'По умолчанию';
$_['text_title_asc']     	= 'По Названию (A - Я)';
$_['text_title_desc']    	= 'По Названию (Я - A)';
$_['text_date_to_asc']   		= 'По Дате начала события (возрастанию)';
$_['text_date_to_desc']  		= 'По Дате начала события (убыванию)';
$_['text_date_from_asc']   		= 'По Дате конца события (возрастанию)';
$_['text_date_from_desc']  		= 'По Дате конца события (убыванию)';
$_['text_limit']        	= 'Показывать:';

$_['event_date_from'] = " по дату ";
$_['event_date_to'] = "C даты ";
