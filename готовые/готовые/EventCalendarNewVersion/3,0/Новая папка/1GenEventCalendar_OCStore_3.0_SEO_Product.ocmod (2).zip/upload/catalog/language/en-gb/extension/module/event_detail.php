<?php

// Text
$_['text_search']                             = 'Search';

// breadcrumbs
$_['event'] = 'Events on the calendar';
$_['event_list'] = 'List of all events';
$_['event_date_from'] = " to date ";
$_['event_date_to'] = "From date ";