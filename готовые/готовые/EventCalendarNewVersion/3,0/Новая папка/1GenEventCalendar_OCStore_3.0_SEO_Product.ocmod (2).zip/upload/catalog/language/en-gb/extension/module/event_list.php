<?php

$_['heading_title'] = 'List of all events';

// Text
$_['text_more'] = 'Details';
$_['text_sort'] = 'Sort:';
$_['text_default'] = 'Default';
$_['text_title_asc'] = 'By Name (A - Z)';
$_['text_title_desc'] = 'By Name (I - A)';
$_['text_date_asc'] = 'By Date (ascending)';
$_['text_date_desc'] = 'By Date (descending)';
$_['text_limit'] = 'Show:';

$_['event_date_from'] = " to date ";
$_['event_date_to'] = "From date ";