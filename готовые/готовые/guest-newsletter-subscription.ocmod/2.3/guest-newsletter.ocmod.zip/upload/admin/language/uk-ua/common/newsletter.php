<?php
// header
$_['Heading_title'] = 'Передплатники';

// Text
$_['Text_list'] = 'Перелік учасників';

// column
$_['Column_name'] = 'Ім`я';
$_['Column_town'] = 'Місто';

