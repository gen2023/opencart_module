<?php
// header
$_['heading_title'] = 'Subscribers';

// Text
$_['text_list'] = 'List of Subscribers';

// column
$_['column_name'] = 'First Name';
$_['column_town'] = 'City';