<?php
class ModelExtensionModuleMymodul extends Model {

		
}