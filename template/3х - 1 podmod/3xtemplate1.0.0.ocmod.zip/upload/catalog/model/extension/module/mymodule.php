<?php
class ModelExtensionModuleMymodule extends Model {

		
}