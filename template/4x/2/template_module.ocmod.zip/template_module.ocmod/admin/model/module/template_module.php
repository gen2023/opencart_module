<?php

namespace Opencart\Admin\Model\Extension\TemplateModule\Module;

class TemplateModule extends \Opencart\System\Engine\Model
{
	public function install(): void
	{
	}

	public function uninstall(): void
	{
	}
}
