<?php
// Heading
$_['heading_title'] = 'Стена категорий';
