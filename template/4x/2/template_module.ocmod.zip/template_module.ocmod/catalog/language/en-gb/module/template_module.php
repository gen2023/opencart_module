<?php
// Heading
$_['heading_title'] = 'Category Wall';
