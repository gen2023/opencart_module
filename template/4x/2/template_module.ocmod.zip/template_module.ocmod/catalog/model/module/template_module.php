<?php

namespace Opencart\Catalog\Model\Extension\TemplateModule\Module;

class TemplateModule extends \Opencart\System\Engine\Model
{
}
