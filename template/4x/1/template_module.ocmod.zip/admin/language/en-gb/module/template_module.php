<?php
// Heading
$_['heading_title']    = 'Template module 4.0.2.3';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified template module module!';
$_['text_edit']        = 'Edit template module Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify template module module!';