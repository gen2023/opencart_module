<?php
// Heading
$_['heading_title']    = 'Store contacts';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have successfully saved the settings!';
$_['text_edit']        = 'Edit Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Attention: You are not authorized to edit the module. Go to System> Users> User Groups and set permissions!';
