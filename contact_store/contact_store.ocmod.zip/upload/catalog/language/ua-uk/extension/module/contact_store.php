<?php
// Heading
$_['heading_title'] = 'Контакти';
$_['text_telephone'] = 'Телефон:';
$_['text_open'] = 'Час роботи:';
$_['store'] = 'Адреса';