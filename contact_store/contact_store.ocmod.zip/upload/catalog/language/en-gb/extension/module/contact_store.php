<?php
// Heading
$_['heading_title'] = 'Contacts';
$_['text_telephone'] = 'Phone:';
$_['text_open'] = 'Work time:';
$_['store'] = 'Address';