<?php
// Heading
$_['heading_title']     = 'Контакты';
$_['text_telephone']     			= 'Телефон:';
$_['text_open']     			= 'Время работы:';
$_['store']     	= 'Адрес';


