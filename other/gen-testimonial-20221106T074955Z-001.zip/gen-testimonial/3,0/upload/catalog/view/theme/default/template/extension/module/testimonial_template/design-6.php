<div class="<?php echo $css_class; ?>">
    <div class="opgtm-testimonial-left">
		<?php if ( isset( $author_image ) && ($display_avatar)) { ?>
			<div class="opgtm-avtar-image"><?php echo $author_image;?></div>
		<?php }?>
	</div>
</div>