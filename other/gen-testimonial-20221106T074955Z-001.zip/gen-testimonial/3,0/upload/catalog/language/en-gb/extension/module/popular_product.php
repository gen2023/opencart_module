<?php
// Heading
$_['heading_title'] = 'Popular product';

// Text
$_['text_tax']      = 'Ex Tax:';