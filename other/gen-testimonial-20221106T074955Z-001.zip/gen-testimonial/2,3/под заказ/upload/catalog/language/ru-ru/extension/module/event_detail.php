<?php

// Text
$_['text_search']                             = 'Поиск';
$_['text_error']        = 'Категория не найдена!';

//breadcrumbs
$_['event']                             = 'События на календаре';
$_['event_list']                             = 'Список всех событий';
$_['event_date_from'] = " по дату ";
$_['event_date_to'] = "Дата";
$_['event_time_from'] = " по ";
$_['event_time_to'] = "Время";
$_['event_price'] = "Цена";