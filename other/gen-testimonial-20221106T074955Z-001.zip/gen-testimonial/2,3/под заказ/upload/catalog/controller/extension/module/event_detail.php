<?php
class ControllerExtensionModuleEventDetail extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('extension/module/event_detail');
		
		$data['event'] = $this->language->get('event');
		$data['event_list'] = $this->language->get('event_list');
		$data['event_date_to'] = $this->language->get('event_date_to');
		$data['event_date_from'] = $this->language->get('event_date_from');
		$data['event_time_to'] = $this->language->get('event_time_to');
		$data['event_time_from'] = $this->language->get('event_time_from');
		$data['event_price'] = $this->language->get('event_price');
		
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/home')
		);

		if (isset($this->request->get['search'])) {
			$url = '';

			if (isset($this->request->get['search'])) {
				$url .= '&search=' . $this->request->get['search'];
			}

			if (isset($this->request->get['description'])) {
				$url .= '&description=' . $this->request->get['description'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}

		}

		if (isset($this->request->get['event_id'])) {
			$event_id = (int)$this->request->get['event_id'];
		} else {
			$event_id = 0;
		}

		$this->load->model('extension/module/event');
		$this->load->model('tool/image');
		
		$event_setting = $this->model_extension_module_event->getEventSetting();
		//var_dump($event_setting);
		$data['event_setting'] = $event_setting;
		
		$event_info = $this->model_extension_module_event->getEvent($event_id);

		if ($event_info) {
			$url = '';

			if (isset($this->request->get['path'])) {
				$url .= '&path=' . $this->request->get['path'];
			}

			if (isset($this->request->get['filter'])) {
				$url .= '&filter=' . $this->request->get['filter'];
			}

			if (isset($this->request->get['search'])) {
				$url .= '&search=' . $this->request->get['search'];
			}

			if (isset($this->request->get['description'])) {
				$url .= '&description=' . $this->request->get['description'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}

			$data['breadcrumbs'][] = array(
				'text' => $data['event'],
				'href' => $this->url->link('extension/module/event')
			);
			
			$data['breadcrumbs'][] = array(
				'text' => $data['event_list'],
				'href' => $this->url->link('extension/module/event_list')
			);
			
			$data['breadcrumbs'][] = array(
				'text' => $event_info['title'],
				'href' => $this->url->link('extension/module/event_detail', $url . '&event_id=' . $this->request->get['event_id'])
			);

			$this->document->addLink($this->url->link('extension/module/event_detail', 'event_id=' . $this->request->get['event_id']), 'canonical');
			
			if (is_file(DIR_IMAGE . $event_info['image'])) {
				$data['image'] = $this->model_tool_image->resize($event_info['image'], 100, 100);
			} else {
				$data['image'] = '';
			}
			
			if ($this->customer->isLogged() || !$this->config->get('config_customer_price')) {
				$price = $this->currency->format($this->tax->calculate($event_info['price'], $this->config->get('config_tax')), $this->session->data['currency']);
			} else {
				$price = false;
			}
			
			$this->document->setTitle($event_info['title']);
			$data['heading_title'] = $event_info['title'];
			$data['heading_title1'] = $event_info['title1'];
			$data['heading_title3'] = $event_info['title3'];
			$data['additional_field'] = $event_info['additional_field'];
            $data['date_To'] = date("d.m.Y", strtotime($event_info['date_to']));
			$data['date_From'] = date("d.m.Y", strtotime($event_info['date_from']));
			$data['time_To'] = date("H:i", strtotime($event_info['time_to']));
			$data['time_From'] = date("H:i", strtotime($event_info['time_from']));
			$data['price'] = $price;
			
			$data['event_id'] = (int)$this->request->get['event_id'];

			$data['description'] = html_entity_decode($event_info['description'], ENT_QUOTES, 'UTF-8');
			
			$products[]=$event_info["product_id"];
			
		//var_dump($products[0]);	
			$this->load->model('catalog/product');
			if  ($products[0]==='0'){$data['product']=0;} else{
			foreach ($products as $product_id) {
				$product_info = $this->model_catalog_product->getProduct($product_id);

				if ($product_info) {
					if ($product_info['image']) {
						$image = $this->model_tool_image->resize($product_info['image'], 100, 100);
					} else {
						$image = $this->model_tool_image->resize('placeholder.png', 100, 100);
					}
					$data['product'][] = array(
						'product_id' => $product_info['product_id'],
						'name'       => $product_info['name'],
						'image'		 => $image,
						'href'       => $this->url->link('product/product', '&product_id=' . $product_info['product_id'])
					);
				}
			}
			}
			
			$doctor_info=$this->model_extension_module_event->getDoctor($event_info["doctor_id"]);
			
			if ($doctor_info) {
					if ($doctor_info['image']) {
						$image = $this->model_tool_image->resize($doctor_info['image'], 100, 100);
					} else {
						$image = $this->model_tool_image->resize('placeholder.png', 100, 100);
					}
					$data['doctor'][] = array(
						'doctor_id' 	=> $doctor_info['doctor_id'],
						'title'       	=> $doctor_info['title'],
						'post'       	=> $doctor_info['post'],
						'image'		 	=> $image,
						'href'        	=> $this->url->link('extension/module/doctor_detail', '&doctor_id=' . $doctor_info['doctor_id'])
					);
				}
		
			$data['column_left'] = $this->load->controller('common/column_left');
			$data['column_right'] = $this->load->controller('common/column_right');
			$data['content_top'] = $this->load->controller('common/content_top');
			$data['content_bottom'] = $this->load->controller('common/content_bottom');
			$data['footer'] = $this->load->controller('common/footer');
			$data['header'] = $this->load->controller('common/header');

			if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/extension/module/event_detail.tpl')) {
				$this->response->setOutput($this->load->view($this->config->get('config_template') . '/template/extension/module/event_detail.tpl', $data));
			} else {
				$this->response->setOutput($this->load->view('extension/module/event_detail.tpl', $data));
			}
		} else {
			$url = '';

			if (isset($this->request->get['path'])) {
				$url .= '&path=' . $this->request->get['path'];
			}

			if (isset($this->request->get['filter'])) {
				$url .= '&filter=' . $this->request->get['filter'];
			}

			if (isset($this->request->get['search'])) {
				$url .= '&search=' . $this->request->get['search'];
			}

			if (isset($this->request->get['description'])) {
				$url .= '&description=' . $this->request->get['description'];
			}

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			if (isset($this->request->get['limit'])) {
				$url .= '&limit=' . $this->request->get['limit'];
			}

			$this->document->setTitle($this->language->get('text_error'));

			$data['heading_title'] = $this->language->get('text_error');

			$data['text_error'] = $this->language->get('text_error');

			$data['button_continue'] = $this->language->get('button_continue');

			$data['continue'] = $this->url->link('common/home');

			$this->response->addHeader($this->request->server['SERVER_PROTOCOL'] . ' 404 Not Found');

			$data['column_left'] = $this->load->controller('common/column_left');
			$data['column_right'] = $this->load->controller('common/column_right');
			$data['content_top'] = $this->load->controller('common/content_top');
			$data['content_bottom'] = $this->load->controller('common/content_bottom');
			$data['footer'] = $this->load->controller('common/footer');
			$data['header'] = $this->load->controller('common/header');

			if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/extension/module/event_detail.tpl')) {
				$this->response->setOutput($this->load->view($this->config->get('config_template') . '/template/extension/module/event_detail.tpl.tpl', $data));
			} else {
				$this->response->setOutput($this->load->view('extension/module/event_detail.tpl', $data));
			}
			
			$this->response->setOutput($this->load->view('error/not_found.tpl', $data));
		}
	}

}
