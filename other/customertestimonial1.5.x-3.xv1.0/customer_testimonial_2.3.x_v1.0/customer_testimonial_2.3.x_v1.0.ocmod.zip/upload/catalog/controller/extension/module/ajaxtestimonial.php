<?php  
	class ControllerExtensionModuleAjaxTestimonial extends Controller {
		
		public function index($setting) {
			$this->language->load('extension/module/ajaxtestimonial');
			
			$data['setting'] = $setting; 
			
			$data['ajaxtestimonial_title'] = $setting['name'];
			
			$data['heading_title'] = $this->language->get('heading_title');
			$data['text_more'] = $this->language->get('text_more');
			$data['text_more2'] = $this->language->get('text_more2');
			$data['ajaxtestimonial_form'] = $this->language->get('ajaxtestimonial_form');
			$data['show_all'] = $this->language->get('show_all');
			$data['showall_url'] = $this->url->link('product/ajaxtestimonial', '', 'SSL'); 
			$data['more'] = $this->url->link('product/ajaxtestimonial', 'ajaxtestimonial_id=' , 'SSL'); 
			$data['ajaxtestimonial_form_url'] = $this->url->link('product/ajaxtestimonial_form', '', 'SSL');
			
		    $data['template_path'] = 'catalog/view/theme/'.$this->config->get('theme_default_directory');
			$this->document->addStyle($data['template_path'].'/stylesheet/ajaxtestimonial.css');
			
			$this->load->model('catalog/ajaxtestimonial');
			
			$data['ajaxtestimonials'] = array();
			
			if ($setting['status']) {
				$results = $this->model_catalog_ajaxtestimonial->getajaxtestimonials_module(0, $setting['limit'], (isset($setting['random']) && $setting['random'] == 1)?true:false);
				
				$this->load->model('tool/image');
				
				foreach ($results as $result) {
					
					$full_review = $data['more']. $result['ajaxtestimonial_id'];
					
					if (!isset($setting['character_limit'])) {
						$setting['character_limit'] = 0;
					}
					
					if ($setting['character_limit'] > 0 ) {
						$lim = $setting['character_limit'];
						
						if (mb_strlen($result['description'],'UTF-8') > $lim) {
							$result['description'] = mb_substr($result['description'], 0, $lim-3, 'UTF-8').'...';
							$result['description'] = strip_tags($result['description'], '<br><p><b>');
						}		
					}
					
					if (mb_strlen($result['name'],'UTF-8') > 20) {
						$result['name'] = mb_substr($result['name'], 0, 7, 'UTF-8').'...';
					}
					
					$data['ajaxtestimonials'][] = array(
					'id'			=> $result['ajaxtestimonial_id'],											  
					'description'	=> $result['description'],
					'rating'		=> $result['rating'],
					'name'		    => $result['name'],
					'date_added'	=> date($this->config->get('ajaxtestimonial_all_page_date_format'), strtotime($result['date_added'])),
					'full_review'   => $full_review
					);
				}
			}
			
			$data['id'] = 'ajaxtestimonial';
			
			return $this->load->view('extension/module/ajaxtestimonial', $data);
		}
	}
?>	