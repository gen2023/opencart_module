<?php
// Heading 
$_['heading_title']		= 'Testimonials';
$_['ajaxtestimonial_form'] 	= 'Write testimonial';
$_['text_more']			= '...';
$_['text_more2']			= 'Read more';
$_['show_all']			= 'Show all testimonials';
$_['text_subject']		= 'Customer %s send testimonial about %s store';
$_['text_header']			= 'Testimonial: ';
$_['text_footer']			= '';
?>