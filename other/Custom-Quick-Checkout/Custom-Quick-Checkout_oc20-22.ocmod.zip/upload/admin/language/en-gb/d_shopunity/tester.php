<?php
$_['heading_title'] = 'Shopunity';
$_['text_edit'] = 'Extensions';


//errors
$_['error_download'] = 'Oops! We counldn\'t download this extension. The following files seem to be missing.';