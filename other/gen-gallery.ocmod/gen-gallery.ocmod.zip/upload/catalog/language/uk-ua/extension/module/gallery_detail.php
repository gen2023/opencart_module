<?php

// Text
$_['text_search']                             = 'Пошук';
$_['text_error'] = 'Категорія не знайдена!';

// breadcrumbs
$_['event'] = 'Події на календарі';
$_['event_list'] = 'Список всіх подій';