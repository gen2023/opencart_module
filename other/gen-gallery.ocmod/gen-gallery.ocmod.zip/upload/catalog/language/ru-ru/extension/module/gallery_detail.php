<?php

// Text
$_['text_search']                             = 'Поиск';
$_['text_error']        = 'Категория не найдена!';

//breadcrumbs
$_['gallery']                             = 'События на календаре';
$_['gallery_list']                             = 'Список всех событий';
